"""Evidence 156: the Paper-1 validation comparisons re-read on the runtime-151 ladder histories.

Read-only. No march is run, no model code is imported. Reads:
  - the measured Faner 2019 soybean 120 C readings (paper/analysis/datasets/faner2019_v2),
    selected exactly as regen/fig_core2_particle_baths.measured() selects them;
  - the manuscript's own histories (the files core2_particle_numbers_audit.json and
    fig_particle_experiments.sources.json pin): Faner N4 temperature-property study,
    DT 2-cell factor-100 K_l 0.32 history;
  - the runtime-151 ladder case trees (ruled film-imbibition bridge, w_sat 0.55);
  - plain-cap (pre-bridge) case trees of runtimes 75, 90, 102, 110 where complete.
Metrics are those of regen/check_core2_particle_results.py (crossings by linear
interpolation between successive states, the 235.058 s holder clock, the 240 s exit,
the DT outlet at 1766.5355 s in ppm wet = h/(1+W+h), moisture = W/(1+W+h), particle-only W).
physically_qualifying: false.
"""

import csv
import json
import math
from pathlib import Path

import numpy as np

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
PAPER = ROOT / "paper"
SCR = ROOT / "scratchpad"
L151 = SCR / "solver_qualification_run_151/paper/analysis/results_2026-10-17/ladder_151"
DT_EXIT = 1766.5355008060146
HOLDER_CLOCK = 235.058
MEAS_FALL = 25.350441949123166


def measured(quantity):
    base = PAPER / "analysis/datasets/faner2019_v2"
    with (base / "adjudication_per_point.csv").open(newline="", encoding="utf-8") as s:
        bands = {r["point_id"]: float(r["uncertainty_abs"]) for r in csv.DictReader(s)}
    with (base / "curves.csv").open(newline="", encoding="utf-8") as s:
        return sorted(
            (float(r["time_s"]), float(r["value"]), bands[r["point_id"]])
            for r in csv.DictReader(s)
            if r["figure"] == "2"
            and r["material"] == "soybean"
            and r["temperature_c"] == "120"
            and r["quantity"] == quantity
            and r["series"] == "experimental"
            and not r["superseded_by"]
        )


def crossing(t, x, level):
    for i in range(len(t) - 1):
        if x[i] >= level >= x[i + 1]:
            if x[i] == x[i + 1]:
                return float(t[i])
            return float(t[i] + (t[i + 1] - t[i]) * (x[i] - level) / (x[i] - x[i + 1]))
    return None


def read_csv(path):
    with path.open(newline="", encoding="utf-8") as s:
        return list(csv.DictReader(s))


def manuscript_faner():
    p = (
        PAPER
        / "analysis/results_2026-10-14/temperature_properties/collected/faner_checker"
        / "volume_mean_N4/history/accepted_history.csv"
    )
    rows = read_csv(p)
    return {
        "source": str(p.relative_to(ROOT)),
        "t": np.array([float(r["t_s"]) for r in rows]),
        "hexane": np.array([float(r["hexane_kg_kg_dry"]) for r in rows]),
        "water": np.array([float(r["water_kg_kg_dry"]) for r in rows]),
        "film": np.zeros(len(rows)),
        "temperature_k": np.array([float(r["mean_temperature_k"]) for r in rows]),
        "core_end_s": next(float(r["t_s"]) for r in rows if float(r["front_z"]) == 0),
        "free_hexane_end_s": max(float(r["t_s"]) for r in rows if r["stage"] == "attached"),
    }


def manuscript_dt():
    p = PAPER / "analysis/results_2026-10-15/dt_factor100/collected/dt_accepted_history.csv"
    rows = read_csv(p)
    ext = np.array([float(r["external_water_kg_kg_dry"]) for r in rows])
    t = np.array([float(r["time_s"]) for r in rows])
    stage = [r["stage"] for r in rows]
    positive = np.nonzero(ext > 0)[0]
    dep = float(t[positive[-1] + 1]) if len(positive) and positive[-1] + 1 < len(t) else None
    mpath = PAPER / "analysis/results_2026-10-15/dt_factor100/collected/dt_checker/outlet_metrics.json"
    m = [e for e in json.loads(mpath.read_text()) if e["K_l_mol_m2_s"] == 0.32][0]
    return {
        "source": str(p.relative_to(ROOT)),
        "t": t,
        "hexane": np.array([float(r["hexane_kg_kg_dry"]) for r in rows]),
        "water": np.array([float(r["particle_water_kg_kg_dry"]) for r in rows]),
        "film": ext,
        "temperature_k": np.array([float(r["temperature_k"]) for r in rows]),
        "film_depletion_s": m["first_film_depletion_time_s"],
        "film_depletion_from_csv_s": dep,
        "core_end_s": m["regime_B_end_time_s"],
        "dry_shell_s": float(t[stage.index("B")]),
    }


def ladder_case(folder, study):
    """Feed rows (Faner: birth.json feed_rows; DT: feed.json rows), then front and dry histories."""
    src = folder / ("birth.json" if study == "Faner" else "feed.json")
    d = json.loads(src.read_text())
    feed = d["feed_rows"] if study == "Faner" else d["rows"]
    t, h, w, f, T = [], [], [], [], []
    for r in feed:
        t.append(r["t_s"])
        h.append(r["hexane_kg_kg_dry"])
        w.append(r["retained_water_kg_kg_dry"])
        f.append(r["external_water_kg_kg_dry"])
        T.append(r["temperature_k"])
    feed_end = t[-1]
    core_end, depletion = None, None
    for name in ("front.history.jsonl", "dry.history.jsonl"):
        for line in (folder / name).read_text().splitlines():
            r = json.loads(line)
            if r["kind"] in ("refusal", "initial") or r["time_s"] <= t[-1]:
                continue
            t.append(r["time_s"])
            h.append(r["hexane_kg_kg_dry"])
            w.append(r["particle_water_kg_kg_dry"])
            f.append(r["external_water_kg_kg_dry"])
            T.append(r["temperature_k"])
            if r.get("front_z") is not None:
                core_end = r["time_s"]
            if r["kind"] == "depletion" and depletion is None:
                depletion = r["time_s"]
    t = np.array(t)
    if not np.all(np.diff(t) > 0):
        raise ValueError("nonchronological " + str(folder))
    case = json.loads((folder / "case.json").read_text())
    return {
        "source": str(folder.relative_to(ROOT)),
        "complete": bool(case.get("complete_history")),
        "bridge": (case.get("numerical_gate_ruling_settings") or {}).get("imbibition_bridge"),
        "t": t,
        "hexane": np.array(h),
        "water": np.array(w),
        "film": np.array(f),
        "temperature_k": np.array(T),
        "free_hexane_end_s": feed_end if study == "Faner" else None,
        "core_end_s": core_end,
        "film_depletion_s": depletion,
    }


def interp(h, key, clock):
    return float(np.interp(clock, h["t"], h[key]))


def faner_metrics(h, meas_x, meas_T):
    c20, c10 = crossing(h["t"], h["hexane"], 0.20), crossing(h["t"], h["hexane"], 0.10)
    tx = np.array([p[0] for p in meas_x])
    vx = np.array([p[1] for p in meas_x])
    ux = np.array([p[2] for p in meas_x])
    tT = np.array([p[0] for p in meas_T])
    vT = np.array([p[1] for p in meas_T])
    rx = np.interp(tx, h["t"], h["hexane"]) - vx
    rT = np.interp(tT, h["t"], h["temperature_k"] - 273.15) - vT
    fall = rx[vx <= 0.20 + 1e-12]
    return {
        "time to X=0.20 (s) [meas 45.9]": c20,
        "interval 0.20 to 0.10 (s) [meas 25.4]": None if c10 is None else c10 - c20,
        "falling-interval shortfall (%)": None if c10 is None else 100 * (1 - (c10 - c20) / MEAS_FALL),
        "core disappearance (s)": h["core_end_s"],
        "free hexane end (s)": h["free_hexane_end_s"],
        "hexane at 240 s (kg/kg dry)": interp(h, "hexane", 240.0),
        "water at 240 s (kg/kg dry)": interp(h, "water", 240.0),
        "mean temperature at 240 s (C)": interp(h, "temperature_k", 240.0) - 273.15,
        "mean temperature at 235.058 s (C) [meas 100.8]": interp(h, "temperature_k", HOLDER_CLOCK)
        - 273.15,
        "[not printed] loading RMS vs all readings (kg/kg)": float(math.sqrt(np.mean(rx**2))),
        "[not printed] loading RMS vs readings at X<=0.20 (kg/kg)": float(
            math.sqrt(np.mean(fall**2))
        ),
        "[not printed] loading readings outside half-width": f"{int(np.sum(np.abs(rx) > ux))} of {len(rx)}",
        "[not printed] temperature RMS vs readings (K)": float(math.sqrt(np.mean(rT**2))),
        "[not printed] temperature mean signed model-reading (K)": float(np.mean(rT)),
    }


def dt_metrics(h):
    W, H = h["water"][-1], h["hexane"][-1]
    out = {
        "outlet time (s)": float(h["t"][-1]),
        "hexane, mg/kg dry": 1e6 * H,
        "hexane, ppm wet [100-500]": 1e6 * H / (1 + W + H),
        "particle moisture, % wet [16-22]": 100 * W / (1 + W + H),
        "volume-mean temperature, C [105-110]": h["temperature_k"][-1] - 273.15,
        "external water film at outlet (kg/kg dry)": float(h["film"][-1]),
        "core extinction (s)": h["core_end_s"],
        "film depletion (s)": h["film_depletion_s"],
    }
    for clock in (503.5, 553.0, 600.0, 703.3, 1000.0, DT_EXIT):
        Wc, Hc = interp(h, "water", clock), interp(h, "hexane", clock)
        out[f"particle water at {clock:.1f} s (kg/kg dry)"] = Wc
        out[f"external film at {clock:.1f} s (kg/kg dry)"] = interp(h, "film", clock)
        out[f"moisture at {clock:.1f} s (% wet)"] = 100 * Wc / (1 + Wc + Hc)
        out[f"hexane at {clock:.1f} s (ppm wet)"] = 1e6 * Hc / (1 + Wc + Hc)
    out["particle water gain 503.5 s to outlet (kg/kg dry)"] = float(W - interp(h, "water", 503.5))
    out["peak particle water (kg/kg dry)"] = float(np.max(h["water"]))
    out["time of peak particle water (s)"] = float(h["t"][int(np.argmax(h["water"]))])
    return out


def maxdiff(a, b, key, lo, hi):
    t = np.union1d(a["t"], b["t"])
    t = t[(t >= lo) & (t <= hi)]
    return float(np.max(np.abs(np.interp(t, a["t"], a[key]) - np.interp(t, b["t"], b[key]))))


def table(block, keys):
    names = list(block)
    lines = ["| quantity | " + " | ".join(names) + " |", "|---|" + "---:|" * len(names)]
    for k in keys:
        cells = []
        for n in names:
            v = block[n].get(k)
            cells.append("" if v is None else (f"{v:.5g}" if isinstance(v, float) else str(v)))
        lines.append(f"| {k} | " + " | ".join(cells) + " |")
    return "\n".join(lines)


def main():
    mx, mT = measured("solvent_loading"), measured("particle_temperature")
    c20 = crossing([p[0] for p in mx], [p[1] for p in mx], 0.20)
    c10 = crossing([p[0] for p in mx], [p[1] for p in mx], 0.10)
    last_T = [p for p in mT if abs(p[0] - HOLDER_CLOCK) < 0.01]
    measured_summary = {
        "loading readings": len(mx),
        "temperature readings": len(mT),
        "loading time span (s)": [mx[0][0], mx[-1][0]],
        "temperature time span (s)": [mT[0][0], mT[-1][0]],
        "time to X=0.20 from readings (s)": c20,
        "interval 0.20 to 0.10 from readings (s)": c10 - c20,
        "holder temperature at 235.058 s (C)": last_T[0][1] if last_T else None,
    }
    errors = {}
    faner_cases = {"manuscript N4": manuscript_faner()}
    for n in (4, 8, 16, 32, 64):
        faner_cases[f"r151 N{n} L1"] = ladder_case(L151 / f"Faner_N{n}_L1", "Faner")
    q = "paper/analysis/results_2026-10-17"
    plain_faner = {
        "plain r110 N4 L1": SCR / f"solver_qualification_run_110/{q}/ladder_110/Faner_N4_L1",
        "plain r75 N8 L1": SCR / f"solver_qualification_run_75/{q}/qualification/Faner_N8_L1",
        "plain r75 N16 L1": SCR / f"solver_qualification_run_75/{q}/qualification/Faner_N16_L1",
        "plain r75 N32 L1": SCR / f"solver_qualification_run_75/{q}/qualification/Faner_N32_L1",
        "plain r110 N64 L1": SCR / f"solver_qualification_run_110/{q}/ladder_110/Faner_N64_L1",
    }
    for k, p in plain_faner.items():
        try:
            faner_cases[k] = ladder_case(p, "Faner")
        except Exception as e:  # noqa: BLE001
            errors[k] = repr(e)
    dt_cases = {"manuscript N2": manuscript_dt()}
    for n in (2, 8, 16, 32, 64):
        dt_cases[f"r151 N{n} L1"] = ladder_case(L151 / f"DT_N{n}_L1", "DT")
    plain_dt = {
        "plain r102 N2 L1": SCR / f"solver_qualification_run_102/{q}/ladder_102/DT_N2_L1",
        "plain r90 N8 L1": SCR / f"solver_qualification_run_90/{q}/qualification_90/DT_N8_L1",
        "plain r90 N16 L1": SCR / f"solver_qualification_run_90/{q}/qualification_90/DT_N16_L1",
        "plain r90 N32 L1": SCR / f"solver_qualification_run_90/{q}/qualification_90/DT_N32_L1",
    }
    for k, p in plain_dt.items():
        try:
            dt_cases[k] = ladder_case(p, "DT")
        except Exception as e:  # noqa: BLE001
            errors[k] = repr(e)

    faner = {
        k: {
            "source": h["source"],
            "complete": h.get("complete", True),
            "bridge": h.get("bridge"),
            "end (s)": float(h["t"][-1]),
            **faner_metrics(h, mx, mT),
        }
        for k, h in faner_cases.items()
    }
    dt = {
        k: {"source": h["source"], "complete": h.get("complete", True), "bridge": h.get("bridge"), **dt_metrics(h)}
        for k, h in dt_cases.items()
    }
    md = dt_cases["manuscript N2"]
    dt["manuscript N2"]["film depletion (s)"] = md["film_depletion_s"]
    dt["manuscript N2"]["film depletion, first zero CSV row (s)"] = md["film_depletion_from_csv_s"]
    dt["manuscript N2"]["dry shell (s)"] = md["dry_shell_s"]

    r2, mf, r4 = dt_cases["r151 N2 L1"], faner_cases["manuscript N4"], faner_cases["r151 N4 L1"]
    history_diffs = {
        "DT N2 r151 vs manuscript: max |W| 0-503.5 s (kg/kg)": maxdiff(md, r2, "water", 0, 503.5),
        "DT N2 r151 vs manuscript: max |W| 503.5-1766.5 s (kg/kg)": maxdiff(md, r2, "water", 503.5, DT_EXIT),
        "DT N2 r151 vs manuscript: max |H| 0-503.5 s (kg/kg)": maxdiff(md, r2, "hexane", 0, 503.5),
        "DT N2 r151 vs manuscript: max |T| whole (K)": maxdiff(md, r2, "temperature_k", 0, DT_EXIT),
        "Faner N4 r151 vs manuscript: max |H| (kg/kg)": maxdiff(mf, r4, "hexane", 0, 240),
        "Faner N4 r151 vs manuscript: max |T| (K)": maxdiff(mf, r4, "temperature_k", 0, 240),
        "Faner N4 r151 vs manuscript: max |W| (kg/kg)": maxdiff(mf, r4, "water", 0, 240),
    }
    if "plain r102 N2 L1" in dt_cases:
        p2 = dt_cases["plain r102 N2 L1"]
        history_diffs["DT N2 plain r102 vs manuscript: max |W| whole (kg/kg)"] = maxdiff(md, p2, "water", 0, DT_EXIT)
        history_diffs["DT N2 plain r102 vs manuscript: max |H| 0-503.5 s (kg/kg)"] = maxdiff(md, p2, "hexane", 0, 503.5)
    result = {
        "evidence": 156,
        "physically_qualifying": False,
        "measured": measured_summary,
        "faner": faner,
        "dt": dt,
        "history_differences": history_diffs,
        "unreadable": errors,
    }
    (OUT / "validation_fit_runtime151_156.json").write_text(
        json.dumps(result, indent=2, default=float), encoding="utf-8"
    )
    fk = [k for k in faner["manuscript N4"] if k not in ("source", "bridge")]
    dk = [k for k in dt["manuscript N2"] if k not in ("source", "bridge")]
    text = [
        "# Evidence 156 tables (generated by validation_fit_runtime151_156.py)",
        "",
        "## Measured (Faner 2019 soybean 120 C, figure 2 readings)",
        "",
        "```",
        json.dumps(measured_summary, indent=1),
        "```",
        "",
        "## Faner",
        "",
        table(faner, fk),
        "",
        "## DT",
        "",
        table(dt, dk),
        "",
        "## History differences",
        "",
        "```",
        json.dumps(history_diffs, indent=1),
        "```",
        "",
        "## Unreadable",
        "",
        "```",
        json.dumps(errors, indent=1),
        "```",
        "",
        "physically_qualifying: false",
    ]
    (OUT / "validation_fit_runtime151_156_tables.md").write_text("\n".join(text), encoding="utf-8")
    print("\n".join(text))


if __name__ == "__main__":
    main()
