"""Evidence 155: the saturated-loading sweep of the ruled bridge, DT at 16 cells, time level 1,
runtime 151, scored against the nominal 0.55 case with the ladder report's own loader.
Read-only. physically_qualifying: false."""

import importlib.util
import json
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
spec = importlib.util.spec_from_file_location("ladder", OUT / "convergence_ladder_report_96.py")
ladder = importlib.util.module_from_spec(spec)
sys.argv = [sys.argv[0]]
spec.loader.exec_module(ladder)

R131 = ROOT / "scratchpad/solver_qualification_run_151/paper/analysis/results_2026-10-17"
cases = {
    0.55: R131 / "ladder_151/DT_N16_L1",
    0.25: R131 / "ladder_151_sweep/DT_N16_L1_wsat0.25",
    0.32: R131 / "ladder_151_sweep/DT_N16_L1_wsat0.32",
    0.75: R131 / "ladder_151_sweep/DT_N16_L1_wsat0.75",
    0.97: R131 / "ladder_151_sweep/DT_N16_L1_wsat0.97",
}
hist = {w: ladder.History("DT", p) for w, p in cases.items()}
ref = hist[0.55]
rows = []
for w in sorted(cases):
    h = hist[w]
    s = ladder.scalars(h)
    stamp = json.loads((cases[w] / "case.json").read_text())
    row = {
        "w_sat": w,
        "stamped_saturated_loading": stamp.get("saturated_loading_kg_kg_dry"),
        "status": stamp.get("status"),
        **{k: s[k] for k in s},
    }
    if w != 0.55:
        c = ladder.scalar.compare(ref.trajectory, h.trajectory)
        row.update(
            {
                "vs 0.55 outlet hexane (% rel)": c["outlet_hexane_relative_percent"],
                "vs 0.55 outlet moisture (pp)": c["outlet_moisture_percentage_points"],
                "vs 0.55 outlet temperature (K)": c["outlet_temperature_k"],
                "vs 0.55 whole-history hexane max rel (%)": c["full_history_hexane_max_relative_percent"],
                "vs 0.55 whole-history moisture max (pp)": c["full_history_moisture_max_percentage_points"],
                "vs 0.55 whole-history temperature max (K)": c["full_history_temperature_max_k"],
            }
        )
    rows.append(row)

keys = [
    "w_sat",
    "status",
    "film-depletion time (s)",
    "core endpoint time (s)",
    "outlet hexane (ppm wet)",
    "outlet moisture (% wet)",
    "outlet temperature (K)",
    "vs 0.55 outlet hexane (% rel)",
    "vs 0.55 outlet moisture (pp)",
    "vs 0.55 outlet temperature (K)",
    "vs 0.55 whole-history hexane max rel (%)",
    "vs 0.55 whole-history moisture max (pp)",
    "vs 0.55 whole-history temperature max (K)",
]
lines = ["# Evidence 155: saturated-loading sweep, DT N16 L1, runtime 151, against nominal 0.55", ""]
lines.append("| " + " | ".join(keys) + " |")
lines.append("|" + "---|" * len(keys))
for r in rows:
    cells = []
    for k in keys:
        v = r.get(k)
        cells.append("" if v is None else (f"{v:.6g}" if isinstance(v, float) else str(v)))
    lines.append("| " + " | ".join(cells) + " |")
lines += ["", "physically_qualifying: false. Read-only scoring of completed, audited cases."]
(OUT / "wsat_sweep_score_155.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
(OUT / "wsat_sweep_score_155.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
print("\n".join(lines))
