"""Windowed history analysis of the convergence ladder (read-only on records).

Owner scoping: outlet quantities are judged at 32 cells; the non-converged part
of the history is localized here. For every usable (complete, unchanged-source,
independently audited; registry of convergence_ladder_report_153.json) DT and
Faner grid pair along the mesh ladder (matched time level, ratio 2) and time
ladder (matched mesh, consecutive levels):

1. error-versus-time curves on the union of both accepted clocks (piecewise
   linear interpolation, no event alignment) for hexane (relative %, with the
   outlet-scale floor of the whole-history norm), moisture (percentage points)
   and temperature (K): CSV and PNG/PDF per pair;
2. the smallest time window holding 95 % of each time-integrated error, overall
   and per phase (fine-grid phase boundaries: feed, moving front to the core
   endpoint, positive film to film depletion, absent film to the outlet; Faner:
   feed, front, dry C stage);
3. windowed maximum and time-mean norms per phase against the declared goals;
4. transition quantities as ladder rows (DT): film-depletion time, cumulative net
   exterior water flux per area up to that instant, surface temperature and the
   outermost-cell retained-water loading at that instant, along both ladders,
   with observed orders where three values exist.

Writes only convergence_history_windows_154.{md,csv,json} and the folder
history_windows_154/. Engineering evidence; physically_qualifying: false.
"""

import csv
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

OUT = Path(__file__).resolve().parent
FIG = OUT / "history_windows_154"
FIG.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location("matrix", OUT / "watch_particle_matrix_30.py")
matrix = importlib.util.module_from_spec(spec)
spec.loader.exec_module(matrix)
GOALS = {  # (spatial, temporal); temperature has no declared whole-history goal
    "hexane_rel_percent": (2.0, 0.5),
    "moisture_pp": (0.05, 0.01),
    "temperature_k": (None, None),
}
UNITS = {"hexane_rel_percent": "% rel (outlet-scale floor)", "moisture_pp": "pp", "temperature_k": "K"}


def rows_of(folder):
    out = []
    for name in ("front.history.jsonl", "dry.history.jsonl"):
        path = folder / name
        if path.exists():
            for line in path.read_text().splitlines():
                row = json.loads(line)
                if row["kind"] not in ("initial", "refusal"):
                    out.append(row)
    return out


def phases(study, folder, rows):
    front = [r["time_s"] for r in rows if r.get("front_z") is not None]
    birth = min(front)
    endpoint = json.loads((folder / "endpoint.json").read_text())["after_transport"]["time_s"]
    end = rows[-1]["time_s"]
    if study == "Faner":
        return {"feed": (0.0, birth), "front": (birth, endpoint), "dry C": (endpoint, end)}
    depletion = next((r["time_s"] for r in rows if r["kind"] == "depletion"), None)
    if depletion is None:
        return {"feed": (0.0, birth), "front": (birth, endpoint), "C": (endpoint, end)}
    return {
        "feed": (0.0, birth),
        "front": (birth, endpoint),
        "positive film": (endpoint, depletion),
        "absent film": (depletion, end),
    }


def transition(rows):
    dep = next((r for r in rows if r["kind"] == "depletion"), None)
    if dep is None:
        return None
    cumulative, previous = 0.0, None
    for r in rows:
        if previous is not None:
            cumulative += r["surface"]["external_water_flux_kg_m2_s"] * (r["time_s"] - previous)
        previous = r["time_s"]
        if r is dep:
            break
    return {
        "film-depletion time (s)": dep["time_s"],
        "cumulative net exterior water flux to depletion (kg/m2)": cumulative,
        "surface temperature at depletion (K)": dep["surface"]["temperature_k"],
        "outermost-cell retained water at depletion (kg/kg dry)": dep["retained_water_cells_kg_kg_dry"][-1],
    }


def curves(coarse, fine):
    t0 = max(coarse[0, 0], fine[0, 0])
    t1 = min(coarse[-1, 0], fine[-1, 0])
    t = np.union1d(coarse[:, 0], fine[:, 0])
    t = t[(t >= t0) & (t <= t1)]
    a = np.column_stack([np.interp(t, coarse[:, 0], coarse[:, i]) for i in (1, 2, 3)])
    b = np.column_stack([np.interp(t, fine[:, 0], fine[:, i]) for i in (1, 2, 3)])
    floor = abs(fine[-1, 1])
    return t, {
        "hexane_rel_percent": 100 * np.abs(a[:, 0] - b[:, 0]) / np.maximum(np.abs(b[:, 0]), floor),
        "moisture_pp": np.abs(a[:, 1] - b[:, 1]),
        "temperature_k": np.abs(a[:, 2] - b[:, 2]),
    }


def integral(t, e):
    return float(np.sum(0.5 * (e[1:] + e[:-1]) * np.diff(t))) if t.size > 1 else 0.0


def window95(t, e, lo=None, hi=None):
    """Smallest [a, b] on knots whose trapezoid integral holds >= 95 % of the total."""
    mask = np.ones(t.size, bool) if lo is None else (t >= lo) & (t <= hi)
    t, e = t[mask], e[mask]
    if t.size < 2:
        return None
    seg = 0.5 * (e[1:] + e[:-1]) * np.diff(t)
    total = float(seg.sum())
    if total <= 0:
        return {"start_s": float(t[0]), "end_s": float(t[0]), "share": 1.0, "integral": 0.0}
    prefix = np.r_[0.0, np.cumsum(seg)]
    best, j = None, 0
    for i in range(t.size):
        j = max(j, i)
        while j < t.size - 1 and prefix[j] - prefix[i] < 0.95 * total:
            j += 1
        if prefix[j] - prefix[i] >= 0.95 * total * (1 - 1e-12):
            if best is None or t[j] - t[i] < best[1] - best[0]:
                best = (float(t[i]), float(t[j]), float((prefix[j] - prefix[i]) / total))
    return {"start_s": best[0], "end_s": best[1], "share": best[2], "integral": total}


def order(values):
    d = [abs(values[i] - values[i + 1]) for i in range(len(values) - 1)]
    p = [math.log2(d[i] / d[i + 1]) if d[i] > 0 and d[i + 1] > 0 else None for i in range(len(d) - 1)]
    signs = [values[i] - values[i + 1] for i in range(len(values) - 1)]
    return d, p, signs


def main():
    report = json.loads((OUT / "convergence_ladder_report_153.json").read_text())
    usable = {}
    for entry in report["registry"]:
        if entry["usable"]:
            usable[(entry["study"], entry["cells"], entry["time_level"])] = Path(entry["case"]).parent
    data = {}
    for key, folder in usable.items():
        rows = rows_of(folder)
        data[key] = {
            "folder": folder,
            "trajectory": matrix.trajectory(folder, key[0]),
            "rows": rows,
            "phases": phases(key[0], folder, rows),
            "transition": transition(rows) if key[0] == "DT" else None,
            "case_sha256": hashlib.sha256((folder / "case.json").read_bytes()).hexdigest(),
        }
    pairs = []
    for study in ("DT", "Faner"):
        for lv in (0, 1, 2):
            cells = sorted(c for s, c, lev in data if s == study and lev == lv)
            for a, b in zip(cells, cells[1:]):
                if b == 2 * a:
                    pairs.append(("mesh", study, (a, lv), (b, lv)))
        for c in sorted({k[1] for k in data if k[0] == study}):
            levels = sorted(lev for s, n, lev in data if s == study and n == c)
            for a, b in zip(levels, levels[1:]):
                if b == a + 1:
                    pairs.append(("time", study, (c, a), (c, b)))
    results, csv_rows = [], []
    for direction, study, (ca, la), (cb, lb) in pairs:
        coarse, fine = data[(study, ca, la)], data[(study, cb, lb)]
        t, errors = curves(coarse["trajectory"], fine["trajectory"])
        name = f"{study}_N{ca}L{la}_vs_N{cb}L{lb}"
        with (FIG / f"{name}.csv").open("w", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(["time_s", *errors])
            for i in range(t.size):
                writer.writerow([repr(float(t[i]))] + [repr(float(errors[k][i])) for k in errors])
        fig, axes = plt.subplots(3, 1, figsize=(8, 8), sharex=True)
        for ax, (k, e) in zip(axes, errors.items()):
            ax.semilogy(t, np.maximum(e, 1e-16), lw=0.8)
            for label, (p0, p1) in fine["phases"].items():
                ax.axvline(p0, color="0.6", lw=0.5)
            ax.set_ylabel(f"{k}\n[{UNITS[k]}]", fontsize=8)
        axes[0].set_title(f"{study} {direction} pair N{ca} L{la} vs N{cb} L{lb} (engineering evidence)", fontsize=9)
        axes[-1].set_xlabel("physical time (s); grey lines: fine-grid phase starts")
        fig.tight_layout()
        fig.savefig(FIG / f"{name}.png", dpi=120)
        fig.savefig(FIG / f"{name}.pdf")
        plt.close(fig)
        goal_index = 0 if direction == "mesh" else 1
        entry = {
            "ladder": direction,
            "study": study,
            "coarse": f"N{ca} L{la}",
            "fine": f"N{cb} L{lb}",
            "curve_csv": str(FIG / f"{name}.csv"),
            "plot": str(FIG / f"{name}.png"),
            "phases_fine": fine["phases"],
            "phases_coarse": coarse["phases"],
            "overall": {},
            "per_phase": {},
            "cases": [str(coarse["folder"] / "case.json"), str(fine["folder"] / "case.json")],
        }
        for k, e in errors.items():
            entry["overall"][k] = {
                "integral": integral(t, e),
                "max": float(e.max()),
                "window95": window95(t, e),
            }
        for phase, (p0, p1) in fine["phases"].items():
            mask = (t >= p0) & (t <= p1)
            entry["per_phase"][phase] = {}
            for k, e in errors.items():
                tt, ee = t[mask], e[mask]
                goal = GOALS[k][goal_index]
                mx = float(ee.max()) if ee.size else None
                mean = integral(tt, ee) / (p1 - p0) if ee.size > 1 and p1 > p0 else None
                share = integral(tt, ee) / entry["overall"][k]["integral"] if entry["overall"][k]["integral"] else None
                entry["per_phase"][phase][k] = {
                    "max": mx,
                    "time_mean": mean,
                    "share_of_history_integral": share,
                    "window95": window95(t, e, p0, p1),
                    "goal_max": goal,
                    "verdict": "no declared goal" if goal is None else ("PASS" if mx is not None and mx <= goal else "FAIL"),
                }
                csv_rows.append([direction, study, entry["coarse"], entry["fine"], phase, k, p0, p1, mx, mean, share, goal,
                                 entry["per_phase"][phase][k]["verdict"]])
        results.append(entry)
    # orders of the windowed integrated error along each ladder (same coarse/fine pattern)
    order_rows = []
    for study in ("DT", "Faner"):
        for direction in ("mesh", "time"):
            chain = [r for r in results if r["study"] == study and r["ladder"] == direction]
            groups = {}
            for r in chain:
                key = r["coarse"].split()[1] if direction == "mesh" else r["coarse"].split()[0]
                groups.setdefault(key, []).append(r)
            for key, group in groups.items():
                if len(group) < 2:
                    continue
                for k in GOALS:
                    for phase in group[-1]["per_phase"]:
                        vals = [g["per_phase"].get(phase, {}).get(k, {}).get("time_mean") for g in group]
                        if None in vals or len(vals) < 2 or min(vals) <= 0:
                            continue
                        p = [math.log2(vals[i] / vals[i + 1]) for i in range(len(vals) - 1)]
                        order_rows.append({"study": study, "ladder": direction, "matched": key, "phase": phase,
                                           "error": k, "pairs": [f"{g['coarse']}->{g['fine']}" for g in group],
                                           "phase_time_mean": vals, "observed_orders": p})
    transitions = []
    for direction in ("mesh", "time"):
        groups = {}
        for (s, c, lev), d in data.items():
            if s != "DT" or d["transition"] is None:
                continue
            groups.setdefault(lev if direction == "mesh" else c, []).append(((c, lev), d["transition"]))
        for key, members in groups.items():
            members.sort()
            if direction == "mesh":
                members = [m for m in members if m[0][0] >= 8]
            if len(members) < 2:
                continue
            for quantity in members[0][1]:
                values = [m[1][quantity] for m in members]
                d, p, signs = order(values)
                transitions.append({"ladder": direction, "matched": f"L{key}" if direction == "mesh" else f"N{key}",
                                    "grids": [f"N{c} L{lev}" for (c, lev), _ in members], "quantity": quantity,
                                    "values": values, "successive_differences": d, "signed_differences": signs,
                                    "observed_orders": p})
    out = {"generated_utc": datetime.now(timezone.utc).isoformat(), "physically_qualifying": False,
           "scope": "windowed localization of history differences; engineering evidence; not a grid-independence claim",
           "pairs": results, "phase_orders": order_rows, "transitions": transitions}
    (OUT / "convergence_history_windows_154.json").write_text(json.dumps(out, indent=2, default=str))
    with (OUT / "convergence_history_windows_154.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["ladder", "study", "coarse", "fine", "phase", "error", "phase_start_s", "phase_end_s",
                         "max", "time_mean", "share_of_history_integral", "goal_max", "verdict"])
        writer.writerows(csv_rows)
    lines = ["# Windowed history analysis (evidence 154, runtime 151)", "",
             f"Generated {out['generated_utc']}. Engineering evidence; `physically_qualifying: false`.", "",
             "Error curves: piecewise-linear interpolation on the union of accepted clocks, no event alignment. "
             "Hexane relative error uses the outlet-scale floor of the declared whole-history norm. "
             "Phases are the fine grid's. Goals are the plan's whole-history goals (spatial for mesh pairs, temporal for time pairs).", ""]
    for r in results:
        lines += [f"## {r['study']} {r['ladder']} pair {r['coarse']} -> {r['fine']}", "",
                  "| Error | 95 % window (s) | Max | Integral |", "|---|---|---:|---:|"]
        for k, v in r["overall"].items():
            w = v["window95"]
            lines.append(f"| {k} | {w['start_s']:.2f} to {w['end_s']:.2f} | {v['max']:.3g} | {v['integral']:.3g} |")
        lines += ["", "| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |",
                  "|---|---|---|---:|---:|---:|---|---:|---|"]
        for phase, block in r["per_phase"].items():
            span = r["phases_fine"][phase]
            for k, v in block.items():
                w = v["window95"]
                ws = f"{w['start_s']:.2f} to {w['end_s']:.2f}" if w else "n/a"
                fmt = lambda x: "n/a" if x is None else f"{x:.3g}"  # noqa: E731
                lines.append(f"| {phase} | {span[0]:.2f} to {span[1]:.2f} | {k} | {fmt(v['max'])} | {fmt(v['time_mean'])} | "
                             f"{fmt(v['share_of_history_integral'])} | {ws} | {v['goal_max']} | {v['verdict']} |")
        lines.append("")
    lines += ["## Transition quantities (DT)", "", "| Ladder | Matched | Grids | Quantity | Values | Successive differences | Observed orders |",
              "|---|---|---|---|---|---|---|"]
    for t in transitions:
        lines.append(f"| {t['ladder']} | {t['matched']} | {', '.join(t['grids'])} | {t['quantity']} | "
                     f"{[float(f'{v:.10g}') for v in t['values']]} | {[float(f'{v:.3g}') for v in t['successive_differences']]} | "
                     f"{[None if p is None else round(p, 3) for p in t['observed_orders']]} |")
    lines += ["", "## Phase time-mean orders", "", "| Study | Ladder | Matched | Phase | Error | Pairs | Time means | Orders |", "|---|---|---|---|---|---|---|---|"]
    for o in order_rows:
        lines.append(f"| {o['study']} | {o['ladder']} | {o['matched']} | {o['phase']} | {o['error']} | {', '.join(o['pairs'])} | "
                     f"{[float(f'{v:.3g}') for v in o['phase_time_mean']]} | {[round(p, 3) for p in o['observed_orders']]} |")
    sidecar = OUT / "convergence_history_windows_154_interpretation.md"
    text = sidecar.read_text() if sidecar.exists() else "(interpretation pending)"
    lines += ["", "## Interpretation (written against the data of this run; re-read when cases are added)", "", text, ""]
    (OUT / "convergence_history_windows_154.md").write_text("\n".join(lines))
    print(json.dumps({"pairs": len(results), "transitions": len(transitions), "phase_orders": len(order_rows)}))


if __name__ == "__main__":
    main()
