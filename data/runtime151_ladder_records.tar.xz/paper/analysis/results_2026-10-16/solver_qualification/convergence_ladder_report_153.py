"""Convergence-ladder report on runtime 151 ONLY (ruled imbibition bridge), evidence 153.

Same instrument as evidence 96, restricted to the runtime-151 ladder (one source generation).
Original description follows.

Builds, for every completed and independently audited DT/Faner case, the
section-4 tables of docs/GT_PS2_PAPER1_SOLVER_PUBLICATION_READINESS_PLAN_2026-10-16.md:
two-grid differences along the mesh ladder (matched time level) and the time
ladder (matched mesh), observed orders log2(d_coarse/d_fine), and a Richardson
extrapolate with a GCI-style estimate (safety factor 1.25) ONLY where the order
is consistent (successive differences of one sign and strictly decreasing, at
least two observed orders, the last within 0.5 of the previous one). Otherwise
it says "no asymptotic range observed" and reports a conservative fine-grid
envelope. Former production resolutions (DT2, Faner4) are compared with the
finest audited grid. Engineering evidence only; physically_qualifying: false.

Writes only convergence_ladder_report_153.{md,csv,json} beside this script.
"""

from bisect import bisect_right
from dataclasses import replace
from datetime import datetime, timezone
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import pickle
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
RT75 = ROOT / "scratchpad/solver_qualification_run_75"
RT90 = ROOT / "scratchpad/solver_qualification_run_90"
RT94 = ROOT / "scratchpad/solver_qualification_run_151"
sys.path[:0] = [str(RT94 / "src"), str(RT94 / "paper/analysis/harness")]
sys.dont_write_bytecode = True
import experiment_core2_dt_birth as radial  # noqa: E402
import particle_imbibition_bridge as imbibition  # noqa: E402

# Radial EOS evaluation on the same ruled law the runtime-151 ladder ran with.
imbibition.install("ruled", imbibition.W_SAT_NOMINAL)

core = radial.core
spec = importlib.util.spec_from_file_location("scalar", OUT / "watch_DT_refinement_22.py")
scalar = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scalar)
spec = importlib.util.spec_from_file_location("matrix", OUT / "watch_particle_matrix_30.py")
matrix = importlib.util.module_from_spec(spec)
spec.loader.exec_module(matrix)

SAFETY = 1.25
# With a single observed order, consistency is judged against a declared formal order:
# time 1 (implicit one-step marching; Faner first-order trend, evidence 55). No formal
# spatial order is declared (moving front and cut cells), so the mesh ladder needs two
# observed orders.
FORMAL_ORDER = {"time": 1.0, "mesh": None}
HORIZON = {"DT": 1766.5355008060146, "Faner": 240.0}
RADIAL_TIMES = {"DT": (520.0, 700.0, 1000.0, 1700.0), "Faner": (60.0, 90.0, 150.0, 230.0)}
FRONT_FRACTIONS = (0.25, 0.5, 0.75)
GOALS = {  # (spatial, temporal) from plan section 4; None = no declared goal
    "outlet hexane (% rel)": (1.0, 0.2),
    "outlet moisture (pp)": (0.02, 0.005),
    "outlet temperature (K)": (0.1, 0.02),
    "whole-history hexane max rel (% , outlet-scale floor)": (2.0, 0.5),
    "whole-history moisture max (pp)": (0.05, 0.01),
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def candidates():
    """(study, cells, level) -> (folder, audit, runtime label); runtime 151 ladder only."""
    out = {}
    ladder = ROOT / "scratchpad/solver_qualification_run_151/paper/analysis/results_2026-10-17/ladder_151"
    if ladder.exists():
        for folder in sorted(ladder.iterdir()):
            if not folder.is_dir():
                continue
            parts = folder.name.split("_")
            if len(parts) != 3:
                continue
            study, n, lv = parts
            out[(study, int(n[1:]), int(lv[1:]))] = (
                folder,
                [OUT / f"ladder151_{folder.name}_original_feed_audit_152.json"],
                "runtime 151",
            )
    return out


def usable_cases():
    registry, usable = [], {}
    for (study, n, lv), (folder, audits, runtime) in sorted(candidates().items()):
        record = matrix.read(folder / "case.json") or {}
        audit_path = next((a for a in audits if a.exists()), None)
        audit = matrix.read(audit_path) if audit_path else None
        entry = {
            "study": study,
            "cells": n,
            "time_level": lv,
            "runtime": runtime,
            "case": str(folder / "case.json"),
            "status": record.get("status", "ABSENT_OR_STARTING"),
            "complete_history": bool(record.get("complete_history")),
            "audit": str(audit_path) if audit_path else None,
            "audit_passed": bool(audit and audit.get("passed") and audit.get("complete_history")),
        }
        if (
            entry["complete_history"]
            and record.get("sources_unchanged_during_run")
            and entry["audit_passed"]
        ):
            entry["case_sha256"] = sha(folder / "case.json")
            entry["audit_sha256"] = sha(audit_path)
            usable[(study, n, lv)] = folder
            entry["usable"] = True
        else:
            entry["usable"] = False
        registry.append(entry)
    return registry, usable


def on_edges(profile, edges):
    old, values = profile
    mid = (edges[:-1] + edges[1:]) / 2
    return values[np.searchsorted(old, mid, side="right") - 1]


def mix(a, b, weight):
    edges = np.union1d(a[0], b[0])
    return edges, (1 - weight) * on_edges(a, edges) + weight * on_edges(b, edges)


def norms(a, b):
    """Exact piecewise-constant overlap in cumulative-volume coordinate (evidence 45/77)."""
    edges = np.union1d(a[0], b[0])
    weights = np.diff(edges)
    left, right = on_edges(a, edges), on_edges(b, edges)
    delta = left - right
    l1 = weights @ abs(delta)
    l2 = np.sqrt(weights @ (delta * delta))
    ref1 = weights @ abs(right)
    ref2 = np.sqrt(weights @ (right * right))
    return l1, l2, ref1, ref2


def self_test():
    a = (np.array([0.0, 1.0]), np.array([[2.0]]))
    c = (np.array([0.0, 0.125, 1.0]), np.array([[3.0], [2.0]]))
    l1, l2, _, _ = norms(c, a)
    assert l1[0] == 0.125 and l2[0] == math.sqrt(0.125)
    assert norms(mix(a, c, 0.5), a)[0][0] == 0.0625


class History:
    def __init__(self, study, folder):
        self.study, self.folder = study, folder
        self.config = pickle.loads((folder / "accepted.pkl").read_bytes())["config"]
        self.rows, self.cache = [], {}
        for name in ("front.history.jsonl", "dry.history.jsonl"):
            for line in (folder / name).read_text().splitlines():
                row = json.loads(line)
                if row["kind"] not in ("refusal", "initial"):
                    self.rows.append(row)
        self.clocks = [r["time_s"] for r in self.rows]
        if not all(b > a for a, b in zip(self.clocks, self.clocks[1:])):
            raise ValueError("radial clocks not strictly chronological: " + str(folder))
        self.trajectory = matrix.trajectory(folder, study)
        self.front = [
            (r["time_s"], r["front_z"]) for r in self.rows if r.get("front_z") is not None
        ]
        self.core_endpoint = max(t for t, _ in self.front) if self.front else None
        dep = [r["time_s"] for r in self.rows if r["kind"] == "depletion"]
        self.depletion = dep[0] if dep else None

    def profile(self, index):
        if index in self.cache:
            return self.cache[index]
        t, cfg = self.rows[index]["after_transport"], self.config
        volumes, values = [], []
        if "geometry" in t:
            wet = iter(zip(t["wet_temperatures_k"], t["wet_retained_water_loadings"]))
            dry = iter(zip(t["dry_temperatures_k"], t["dry_y_hexane"]))
            dual = iter(
                t.get("wet_retained_water_capacity_duals_over_rt")
                or [0.0] * len(t["wet_temperatures_k"])
            )
            for i, cell in enumerate(t["geometry"]["cells"]):
                if cell["wet_volume_m3"]:
                    temp, water = next(wet)
                    state = radial.ww.evaluate_cell(
                        temp,
                        water,
                        t["historical_hexane_loadings"][i],
                        t["oil_fraction_labels"][i],
                        cfg.wet,
                        retained_water_capacity_dual_over_rt=next(dual),
                    )
                    volumes.append(cell["wet_volume_m3"])
                    values.append(
                        [
                            state.retained_water_concentration_mol_m3 * core.wa.M,
                            state.total_hexane_concentration_kg_m3,
                            temp,
                        ]
                    )
                if cell["dry_volume_m3"]:
                    temp, y = next(dry)
                    state = core.cp.evaluate_equilibrium(
                        temp,
                        cfg.dry.pressure_pa,
                        y,
                        replace(cfg.dry.pore, w_o=t["oil_fraction_labels"][i]),
                    )
                    volumes.append(cell["dry_volume_m3"])
                    values.append(
                        [
                            state.total_water_concentration_mol_m3 * core.wa.M,
                            state.total_hexane_concentration_mol_m3 * core.hx.M,
                            temp,
                        ]
                    )
        else:
            for volume, temp, y in zip(t["grid"]["volumes"], t["temperatures_k"], t["y_hexane"]):
                state = core.cp.evaluate_equilibrium(temp, cfg.dry.pressure_pa, y, cfg.dry.pore)
                volumes.append(volume)
                values.append(
                    [
                        state.total_water_concentration_mol_m3 * core.wa.M,
                        state.total_hexane_concentration_mol_m3 * core.hx.M,
                        temp,
                    ]
                )
        total = math.fsum(volumes)
        edges = np.array([0.0] + [math.fsum(volumes[: i + 1]) / total for i in range(len(volumes))])
        profile = edges, np.array(values)
        self.cache[index] = profile
        return profile

    def at(self, clock):
        if not self.clocks[0] <= clock <= self.clocks[-1]:
            return None
        i = bisect_right(self.clocks, clock) - 1
        if self.clocks[i] == clock:
            return self.profile(i)
        w = (clock - self.clocks[i]) / (self.clocks[i + 1] - self.clocks[i])
        return mix(self.profile(i), self.profile(i + 1), w)

    def front_at(self, clock):
        times = [t for t, _ in self.front]
        if not self.front or not times[0] <= clock <= times[-1]:
            return None
        return float(np.interp(clock, times, [z for _, z in self.front]))


def scalars(h):
    last = h.trajectory[-1]
    return {
        "outlet hexane (ppm wet)": float(last[1]),
        "outlet moisture (% wet)": float(last[2]),
        "outlet temperature (K)": float(last[3]),
        "core endpoint time (s)": h.core_endpoint,
        "film-depletion time (s)": h.depletion,
    }


def pair_metrics(hc, hf, study, front_times):
    c = scalar.compare(hc.trajectory, hf.trajectory)
    out = {
        "outlet hexane (% rel)": c["outlet_hexane_relative_percent"],
        "outlet moisture (pp)": c["outlet_moisture_percentage_points"],
        "outlet temperature (K)": c["outlet_temperature_k"],
        "whole-history hexane max rel (% , outlet-scale floor)": c[
            "full_history_hexane_max_relative_percent"
        ],
        "whole-history moisture max (pp)": c["full_history_moisture_max_percentage_points"],
        "whole-history temperature max (K)": c["full_history_temperature_max_k"],
    }
    for name in ("core endpoint time (s)", "film-depletion time (s)"):
        a, b = scalars(hc)[name], scalars(hf)[name]
        out[name] = abs(a - b) if a is not None and b is not None else None
    for t in front_times:
        a, b = hc.front_at(t), hf.front_at(t)
        out[f"front z at {t:.3f} s"] = abs(a - b) if a is not None and b is not None else None
    for t in RADIAL_TIMES[study]:
        pa, pb = hc.at(t), hf.at(t)
        if pa is None or pb is None:
            continue
        l1, l2, r1, r2 = norms(pa, pb)
        out[f"radial water L1 rel % at {t:g} s"] = float(100 * l1[0] / r1[0])
        out[f"radial water L2 rel % at {t:g} s"] = float(100 * l2[0] / r2[0])
        out[f"radial hexane L1 rel % at {t:g} s"] = float(100 * l1[1] / r1[1])
        out[f"radial hexane L2 rel % at {t:g} s"] = float(100 * l2[1] / r2[1])
        out[f"radial temperature L1 (K) at {t:g} s"] = float(l1[2])
        out[f"radial temperature L2 (K) at {t:g} s"] = float(l2[2])
    return out


def scalar_values(h, front_times):
    v = scalars(h)
    for t in front_times:
        v[f"front z at {t:.3f} s"] = h.front_at(t)
    return v


SCALAR_UNITS = {
    "outlet hexane (% rel)": ("outlet hexane (ppm wet)", "relative"),
    "outlet moisture (pp)": ("outlet moisture (% wet)", "absolute"),
    "outlet temperature (K)": ("outlet temperature (K)", "absolute"),
    "core endpoint time (s)": ("core endpoint time (s)", "absolute"),
    "film-depletion time (s)": ("film-depletion time (s)", "absolute"),
}


def assess(values, pairs, kind, formal=None):
    """values: per-grid scalar list (or None); pairs: consecutive pair metrics (>=0)."""
    result = {"orders": [], "consistent": False, "richardson": None}
    if any(p is None for p in pairs) or not pairs:
        result.update(estimate=None, estimate_kind="insufficient data")
        return result
    signed = None
    if values is not None and all(v is not None for v in values):
        signed = [values[i] - values[i + 1] for i in range(len(values) - 1)]
    mags = [abs(s) for s in signed] if signed else list(pairs)
    orders = [
        math.log2(mags[i] / mags[i + 1]) if mags[i] > 0 and mags[i + 1] > 0 else None
        for i in range(len(mags) - 1)
    ]
    result["orders"] = orders
    same_sign = signed is None or all(s != 0 and (s > 0) == (signed[0] > 0) for s in signed)
    decreasing = all(mags[i] > mags[i + 1] > 0 for i in range(len(mags) - 1))
    reference = orders[-2] if len(orders) >= 2 else formal
    consistent = (
        len(orders) >= 1
        and reference is not None
        and same_sign
        and decreasing
        and all(o is not None for o in orders)
        and abs(orders[-1] - reference) <= 0.5
    )
    result["consistent"] = consistent
    finest_pair = pairs[-1]
    if consistent:
        p = orders[-1]
        result["estimate"] = SAFETY * finest_pair / (2**p - 1)
        result["estimate_kind"] = f"GCI fine-grid, Fs={SAFETY}, p={p:.3f}"
        if values is not None and signed:
            qf, qc = values[-1], values[-2]
            result["richardson"] = qf + (qf - qc) / (2**p - 1)
    else:
        result["estimate"] = max(pairs[-2:])
        result["estimate_kind"] = (
            "no asymptotic range observed; fine-grid envelope = max of the last two "
            "two-grid differences (observed, not a bound)"
            if len(pairs) >= 2
            else "two-grid difference only (no order)"
        )
    return result


def verdict(goal, estimate):
    if goal is None:
        return "no declared goal"
    if estimate is None:
        return "insufficient"
    return "PASS" if estimate <= goal else "FAIL"


def ladder_rows(direction, study, fixed, grids, cache, usable):
    """grids: list of (cells, level) along the ladder, coarse to fine, all usable."""
    hs = [cache[(study, c, lv)] for c, lv in grids]
    common = [h.front for h in hs if h.front]
    front_times = ()
    if len(common) == len(hs):
        start = max(f[0][0] for f in common)
        end = min(f[-1][0] for f in common)
        if end > start:
            front_times = tuple(start + q * (end - start) for q in FRONT_FRACTIONS)
    pairs = [pair_metrics(hs[i], hs[i + 1], study, front_times) for i in range(len(hs) - 1)]
    values = [scalar_values(h, front_times) for h in hs]
    rows = []
    for name in pairs[0]:
        series = [p.get(name) for p in pairs]
        base = SCALAR_UNITS.get(name)
        vals = None
        if base:
            vals = [v[base[0]] for v in values]
        elif name.startswith("front z at"):
            vals = [v.get(name) for v in values]
        a = assess(vals, series, name, FORMAL_ORDER[direction])
        goal_pair = GOALS.get(name)
        goal = None if goal_pair is None else goal_pair[0 if direction == "mesh" else 1]
        estimate = a.get("estimate")  # in the pair metric's units (relative % for hexane)
        rows.append(
            {
                "ladder": direction,
                "study": study,
                "matched": fixed,
                "grids": " / ".join(f"N{c} L{lv}" for c, lv in grids),
                "observable": name,
                "per_grid_values": None if vals is None else [_r(v) for v in vals],
                "two_grid_differences": [_r(s) for s in series],
                "observed_orders": [_r(o) for o in a["orders"]],
                "order_consistent": a["consistent"],
                "richardson_extrapolate": _r(a["richardson"]),
                "estimate_kind": a["estimate_kind"],
                "estimate": _r(estimate),
                "goal": goal,
                "verdict": verdict(goal, estimate),
                "cases": [str(usable[(study, c, lv)] / "case.json") for c, lv in grids],
            }
        )
    return rows


def _r(x):
    return None if x is None else float(f"{x:.6g}")


def main():
    self_test()
    registry, usable = usable_cases()
    cache = {}
    for key, folder in usable.items():
        cache[key] = History(key[0], folder)
    rows = []
    for study in ("DT", "Faner"):
        cells_all = sorted({k[1] for k in usable if k[0] == study and k[1] >= 4})
        for lv in (0, 1, 2):
            ladder = [
                c
                for c in cells_all
                if (study, c, lv) in usable and c >= (8 if study == "DT" else 4)
            ]
            chain = []
            for c in ladder:
                if not chain or c == 2 * chain[-1]:
                    chain.append(c)
                else:
                    chain = [c]
            if len(chain) >= 2:
                rows += ladder_rows(
                    "mesh", study, f"time level {lv}", [(c, lv) for c in chain], cache, usable
                )
        for c in cells_all:
            levels = [lv for lv in (0, 1, 2) if (study, c, lv) in usable]
            chain = []
            for lv in levels:
                if not chain or lv == chain[-1] + 1:
                    chain.append(lv)
                else:
                    chain = [lv]
            if len(chain) >= 2:
                rows += ladder_rows(
                    "time", study, f"N{c}", [(c, lv) for lv in chain], cache, usable
                )
    former = []
    for study, cells, level in (("DT", 2, 1), ("DT", 2, 0), ("Faner", 4, 1), ("Faner", 4, 0)):
        key = (study, cells, level)
        finest = max(
            (k for k in usable if k[0] == study and k[2] == level and k[1] != cells),
            default=None,
        )
        if key in usable and finest:
            m = pair_metrics(cache[key], cache[finest], study, ())
            for name, value in m.items():
                goal_pair = GOALS.get(name)
                former.append(
                    {
                        "ladder": "former production vs finest audited",
                        "study": study,
                        "matched": f"time level {level}",
                        "grids": f"N{cells} L{level} vs N{finest[1]} L{level}",
                        "observable": name,
                        "two_grid_differences": [_r(value)],
                        "estimate_kind": "observed difference to finest audited grid",
                        "estimate": _r(value),
                        "goal": None if goal_pair is None else goal_pair[0],
                        "verdict": verdict(None if goal_pair is None else goal_pair[0], value),
                        "cases": [
                            str(usable[key] / "case.json"),
                            str(usable[finest] / "case.json"),
                        ],
                    }
                )
    report = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "engineering evidence; physically_qualifying: false; not a grid-independence claim",
        "physically_qualifying": False,
        "safety_factor": SAFETY,
        "consistency_rule": "two-grid differences of one sign, strictly decreasing, the last observed "
        "order within 0.5 of the previous order, or (one order only) of the declared formal "
        "order (time 1; no declared spatial order) "
        "; otherwise no asymptotic range observed",
        "whole_history_hexane_floor": "relative norm denominator max(|fine|, |fine outlet|) "
        "(watch_DT_refinement_22.compare)",
        "radial_quadrature": "exact piecewise-constant overlap in cumulative-volume coordinate; "
        "linear in time between accepted endpoints; exterior film excluded (evidence 45/77)",
        "radial_times_s": RADIAL_TIMES,
        "front_times": "fractions 0.25/0.5/0.75 of the common front interval of each ladder",
        "goals_spatial_temporal": GOALS,
        "registry": registry,
        "ladder_rows": rows,
        "former_production_rows": former,
    }
    (OUT / "convergence_ladder_report_153.json").write_text(json.dumps(report, indent=2))
    fields = [
        "ladder",
        "study",
        "matched",
        "grids",
        "observable",
        "per_grid_values",
        "two_grid_differences",
        "observed_orders",
        "order_consistent",
        "richardson_extrapolate",
        "estimate_kind",
        "estimate",
        "goal",
        "verdict",
        "cases",
    ]
    with (OUT / "convergence_ladder_report_153.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows + former:
            writer.writerow(
                {
                    k: json.dumps(row.get(k)) if isinstance(row.get(k), list) else row.get(k)
                    for k in fields
                }
            )
    lines = [
        "# Convergence ladder report (evidence 96)",
        "",
        f"Generated {report['generated_utc']}. Engineering evidence; `physically_qualifying: false`.",
        "Not a grid-independence claim. Every row cites its case files; audits are in the registry.",
        "",
        f"Consistency rule: {report['consistency_rule']}. GCI safety factor {SAFETY}.",
        "",
        "## Case registry",
        "",
        "| Study | N | L | Runtime | Status | Audit passed | Usable |",
        "|---|---:|---:|---|---|---|---|",
    ]
    for e in registry:
        lines.append(
            f"| {e['study']} | {e['cells']} | {e['time_level']} | {e['runtime']} | {e['status']} | "
            f"{e['audit_passed']} | {e['usable']} |"
        )
    for title, block in (("Ladders", rows), ("Former production resolutions", former)):
        lines += [
            "",
            f"## {title}",
            "",
            "| Ladder | Study | Matched | Grids | Observable | Differences | Orders | Consistent | Richardson | Estimate | Goal | Verdict |",
            "|---|---|---|---|---|---|---|---|---|---|---|---|",
        ]
        for r in block:
            lines.append(
                f"| {r['ladder']} | {r['study']} | {r['matched']} | {r['grids']} | {r['observable']} | "
                f"{r.get('two_grid_differences')} | {r.get('observed_orders', '')} | "
                f"{r.get('order_consistent', '')} | {r.get('richardson_extrapolate', '')} | "
                f"{r['estimate']} ({r['estimate_kind']}) | {r['goal']} | {r['verdict']} |"
            )
    (OUT / "convergence_ladder_report_153.md").write_text("\n".join(lines) + "\n")
    print(
        json.dumps(
            {
                "usable_cases": len(usable),
                "ladder_rows": len(rows),
                "former_rows": len(former),
                "PASS": sum(r["verdict"] == "PASS" for r in rows + former),
                "FAIL": sum(r["verdict"] == "FAIL" for r in rows + former),
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
    # Evidence 113: the windowed history analysis is regenerated with every report.
    import subprocess

    subprocess.run([sys.executable, str(OUT / "convergence_history_windows_154.py")], cwd=OUT, check=False)
