# Windowed history analysis (evidence 154, runtime 151)

Generated 2026-10-18T12:00:54.043891+00:00. Engineering evidence; `physically_qualifying: false`.

Error curves: piecewise-linear interpolation on the union of accepted clocks, no event alignment. Hexane relative error uses the outlet-scale floor of the declared whole-history norm. Phases are the fine grid's. Goals are the plan's whole-history goals (spatial for mesh pairs, temporal for time pairs).

## DT mesh pair N8 L0 -> N16 L0

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 495.04 to 1738.93 | 22.6 | 1.63e+03 |
| moisture_pp | 734.21 to 1766.54 | 0.178 | 161 |
| temperature_k | 492.69 to 1724.21 | 0.727 | 61.8 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.36 | hexane_rel_percent | 0.0678 | 8.99e-06 | 2.71e-06 | 492.26 to 492.36 | 2.0 | PASS |
| feed | 0.00 to 492.36 | moisture_pp | 0.00368 | 5.22e-07 | 1.59e-06 | 492.26 to 492.36 | 0.05 | PASS |
| feed | 0.00 to 492.36 | temperature_k | 0.0717 | 1e-05 | 7.97e-05 | 492.26 to 492.36 | None | no declared goal |
| front | 492.36 to 502.54 | hexane_rel_percent | 22.6 | 10.4 | 0.0647 | 495.44 to 502.52 | 2.0 | FAIL |
| front | 492.36 to 502.54 | moisture_pp | 0.111 | 0.0676 | 0.00427 | 494.24 to 502.54 | 0.05 | FAIL |
| front | 492.36 to 502.54 | temperature_k | 0.727 | 0.389 | 0.0641 | 493.83 to 502.54 | None | no declared goal |
| positive film | 502.54 to 553.93 | hexane_rel_percent | 5.07 | 1.37 | 0.043 | 502.54 to 542.43 | 2.0 | FAIL |
| positive film | 502.54 to 553.93 | moisture_pp | 0.0364 | 0.00504 | 0.00161 | 502.54 to 552.43 | 0.05 | PASS |
| positive film | 502.54 to 553.93 | temperature_k | 0.459 | 0.0543 | 0.0452 | 502.54 to 522.43 | None | no declared goal |
| absent film | 553.93 to 1766.54 | hexane_rel_percent | 3.24 | 1.2 | 0.892 | 639.21 to 1766.54 | 2.0 | FAIL |
| absent film | 553.93 to 1766.54 | moisture_pp | 0.178 | 0.132 | 0.994 | 744.21 to 1766.54 | 0.05 | FAIL |
| absent film | 553.93 to 1766.54 | temperature_k | 0.0934 | 0.0454 | 0.891 | 574.21 to 1738.93 | None | no declared goal |

## DT mesh pair N16 L0 -> N32 L0

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 495.87 to 1703.93 | 11.3 | 1.78e+03 |
| moisture_pp | 699.04 to 1766.54 | 0.186 | 174 |
| temperature_k | 547.61 to 1766.54 | 0.329 | 67.3 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.36 | hexane_rel_percent | 0.0206 | 3.34e-06 | 9.27e-07 | 492.25 to 492.36 | 2.0 | PASS |
| feed | 0.00 to 492.36 | moisture_pp | 0.00161 | 2.93e-07 | 8.29e-07 | 492.25 to 492.36 | 0.05 | PASS |
| feed | 0.00 to 492.36 | temperature_k | 0.0287 | 5.04e-06 | 3.69e-05 | 492.25 to 492.36 | None | no declared goal |
| front | 492.36 to 502.61 | hexane_rel_percent | 11.3 | 5.32 | 0.0307 | 494.99 to 502.59 | 2.0 | FAIL |
| front | 492.36 to 502.61 | moisture_pp | 0.0541 | 0.0341 | 0.00201 | 494.10 to 502.48 | 0.05 | FAIL |
| front | 492.36 to 502.61 | temperature_k | 0.329 | 0.189 | 0.0288 | 493.26 to 502.57 | None | no declared goal |
| positive film | 502.61 to 554.04 | hexane_rel_percent | 2.7 | 0.803 | 0.0233 | 502.61 to 547.54 | 2.0 | FAIL |
| positive film | 502.61 to 554.04 | moisture_pp | 0.0166 | 0.00323 | 0.000955 | 502.61 to 552.54 | 0.05 | PASS |
| positive film | 502.61 to 554.04 | temperature_k | 0.226 | 0.0277 | 0.0212 | 502.61 to 522.54 | None | no declared goal |
| absent film | 554.04 to 1766.54 | hexane_rel_percent | 2.66 | 1.39 | 0.946 | 564.04 to 1708.93 | 2.0 | FAIL |
| absent film | 554.04 to 1766.54 | moisture_pp | 0.186 | 0.143 | 0.997 | 698.93 to 1758.93 | 0.05 | FAIL |
| absent film | 554.04 to 1766.54 | temperature_k | 0.154 | 0.0527 | 0.95 | 559.04 to 1718.93 | None | no declared goal |

## DT mesh pair N32 L0 -> N64 L0

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 494.84 to 1648.46 | 4.57 | 1.31e+03 |
| moisture_pp | 604.04 to 1698.46 | 0.152 | 143 |
| temperature_k | 554.04 to 1723.46 | 0.223 | 57.2 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.31 | hexane_rel_percent | 0.0177 | 1.65e-06 | 6.23e-07 | 492.25 to 492.31 | 2.0 | PASS |
| feed | 0.00 to 492.31 | moisture_pp | 0.00309 | 2.21e-07 | 7.63e-07 | 492.26 to 492.31 | 0.05 | PASS |
| feed | 0.00 to 492.31 | temperature_k | 0.0445 | 3.39e-06 | 2.91e-05 | 492.25 to 492.31 | None | no declared goal |
| front | 492.31 to 502.63 | hexane_rel_percent | 4.57 | 2.09 | 0.0165 | 494.94 to 502.60 | 2.0 | FAIL |
| front | 492.31 to 502.63 | moisture_pp | 0.0226 | 0.0141 | 0.00102 | 494.17 to 502.63 | 0.05 | PASS |
| front | 492.31 to 502.63 | temperature_k | 0.15 | 0.0826 | 0.0149 | 493.17 to 502.62 | None | no declared goal |
| positive film | 502.63 to 553.46 | hexane_rel_percent | 1.03 | 0.251 | 0.00975 | 502.63 to 552.61 | 2.0 | PASS |
| positive film | 502.63 to 553.46 | moisture_pp | 0.00627 | 0.00135 | 0.000481 | 502.63 to 552.61 | 0.05 | PASS |
| positive film | 502.63 to 553.46 | temperature_k | 0.0868 | 0.0108 | 0.00958 | 502.63 to 522.61 | None | no declared goal |
| absent film | 553.46 to 1766.54 | hexane_rel_percent | 3.78 | 1.05 | 0.974 | 554.04 to 1653.46 | 2.0 | FAIL |
| absent film | 553.46 to 1766.54 | moisture_pp | 0.152 | 0.118 | 0.998 | 608.46 to 1699.04 | 0.05 | FAIL |
| absent film | 553.46 to 1766.54 | temperature_k | 0.223 | 0.046 | 0.976 | 554.04 to 1683.46 | None | no declared goal |

## DT mesh pair N8 L1 -> N16 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 494.23 to 1738.43 | 23.6 | 1.63e+03 |
| moisture_pp | 730.93 to 1765.64 | 0.178 | 161 |
| temperature_k | 493.41 to 1725.64 | 0.755 | 61.4 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.31 | hexane_rel_percent | 0.066 | 3.77e-06 | 1.14e-06 | 492.26 to 492.31 | 2.0 | PASS |
| feed | 0.00 to 492.31 | moisture_pp | 0.00359 | 2.19e-07 | 6.68e-07 | 492.26 to 492.31 | 0.05 | PASS |
| feed | 0.00 to 492.31 | temperature_k | 0.0704 | 4.25e-06 | 3.41e-05 | 492.26 to 492.31 | None | no declared goal |
| front | 492.31 to 502.47 | hexane_rel_percent | 23.6 | 10.8 | 0.0671 | 495.41 to 502.46 | 2.0 | FAIL |
| front | 492.31 to 502.47 | moisture_pp | 0.116 | 0.0696 | 0.00438 | 494.26 to 502.43 | 0.05 | FAIL |
| front | 492.31 to 502.47 | temperature_k | 0.755 | 0.402 | 0.0664 | 493.81 to 502.46 | None | no declared goal |
| positive film | 502.47 to 553.14 | hexane_rel_percent | 5.3 | 1.3 | 0.0404 | 502.47 to 542.31 | 2.0 | FAIL |
| positive film | 502.47 to 553.14 | moisture_pp | 0.0384 | 0.00505 | 0.00158 | 502.47 to 549.81 | 0.05 | PASS |
| positive film | 502.47 to 553.14 | temperature_k | 0.49 | 0.0464 | 0.0382 | 502.47 to 517.31 | None | no declared goal |
| absent film | 553.14 to 1766.54 | hexane_rel_percent | 3.29 | 1.2 | 0.893 | 640.93 to 1766.54 | 2.0 | FAIL |
| absent film | 553.14 to 1766.54 | moisture_pp | 0.178 | 0.132 | 0.994 | 743.43 to 1765.93 | 0.05 | FAIL |
| absent film | 553.14 to 1766.54 | temperature_k | 0.0934 | 0.0453 | 0.895 | 580.93 to 1745.64 | None | no declared goal |

## DT mesh pair N16 L1 -> N32 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 493.85 to 1700.64 | 12 | 1.77e+03 |
| moisture_pp | 693.14 to 1760.72 | 0.187 | 175 |
| temperature_k | 558.22 to 1766.54 | 0.329 | 67.3 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.31 | hexane_rel_percent | 0.0275 | 1.95e-06 | 5.4e-07 | 492.26 to 492.31 | 2.0 | PASS |
| feed | 0.00 to 492.31 | moisture_pp | 0.00187 | 1.48e-07 | 4.16e-07 | 492.26 to 492.31 | 0.05 | PASS |
| feed | 0.00 to 492.31 | temperature_k | 0.0341 | 2.69e-06 | 1.97e-05 | 492.26 to 492.31 | None | no declared goal |
| front | 492.31 to 502.54 | hexane_rel_percent | 12 | 5.53 | 0.0319 | 494.93 to 502.53 | 2.0 | FAIL |
| front | 492.31 to 502.54 | moisture_pp | 0.0546 | 0.0353 | 0.00207 | 493.97 to 502.30 | 0.05 | FAIL |
| front | 492.31 to 502.54 | temperature_k | 0.329 | 0.197 | 0.0299 | 493.19 to 502.45 | None | no declared goal |
| positive film | 502.54 to 553.22 | hexane_rel_percent | 2.93 | 0.768 | 0.022 | 502.54 to 544.97 | 2.0 | FAIL |
| positive film | 502.54 to 553.22 | moisture_pp | 0.0179 | 0.00379 | 0.0011 | 502.54 to 552.47 | 0.05 | PASS |
| positive film | 502.54 to 553.22 | temperature_k | 0.251 | 0.0246 | 0.0185 | 502.54 to 517.47 | None | no declared goal |
| absent film | 553.22 to 1766.54 | hexane_rel_percent | 2.68 | 1.38 | 0.946 | 563.22 to 1708.14 | 2.0 | FAIL |
| absent film | 553.22 to 1766.54 | moisture_pp | 0.187 | 0.144 | 0.997 | 690.72 to 1753.14 | 0.05 | FAIL |
| absent film | 553.22 to 1766.54 | temperature_k | 0.156 | 0.0528 | 0.952 | 560.72 to 1718.14 | None | no declared goal |

## DT mesh pair N32 L1 -> N64 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 493.26 to 1648.22 | 5.28 | 1.31e+03 |
| moisture_pp | 610.13 to 1705.13 | 0.153 | 143 |
| temperature_k | 552.63 to 1723.22 | 0.229 | 57.5 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.31 | hexane_rel_percent | 0.00787 | 5.37e-07 | 2.02e-07 | 492.26 to 492.31 | 2.0 | PASS |
| feed | 0.00 to 492.31 | moisture_pp | 0.000836 | 7.37e-08 | 2.53e-07 | 492.26 to 492.31 | 0.05 | PASS |
| feed | 0.00 to 492.31 | temperature_k | 0.0149 | 1.21e-06 | 1.04e-05 | 492.26 to 492.31 | None | no declared goal |
| front | 492.31 to 502.59 | hexane_rel_percent | 5.28 | 2.37 | 0.0186 | 494.88 to 502.56 | 2.0 | FAIL |
| front | 492.31 to 502.59 | moisture_pp | 0.0255 | 0.0158 | 0.00113 | 493.85 to 502.32 | 0.05 | PASS |
| front | 492.31 to 502.59 | temperature_k | 0.144 | 0.0926 | 0.0166 | 493.21 to 502.56 | None | no declared goal |
| positive film | 502.59 to 552.63 | hexane_rel_percent | 1.15 | 0.247 | 0.00948 | 502.59 to 550.04 | 2.0 | PASS |
| positive film | 502.59 to 552.63 | moisture_pp | 0.00701 | 0.00177 | 0.000617 | 502.59 to 550.04 | 0.05 | PASS |
| positive film | 502.59 to 552.63 | temperature_k | 0.102 | 0.0105 | 0.00918 | 502.59 to 517.54 | None | no declared goal |
| absent film | 552.63 to 1766.54 | hexane_rel_percent | 3.86 | 1.05 | 0.972 | 553.22 to 1652.63 | 2.0 | FAIL |
| absent film | 552.63 to 1766.54 | moisture_pp | 0.153 | 0.118 | 0.998 | 608.22 to 1700.13 | 0.05 | FAIL |
| absent film | 552.63 to 1766.54 | temperature_k | 0.229 | 0.0461 | 0.974 | 553.22 to 1682.63 | None | no declared goal |

## DT mesh pair N8 L2 -> N16 L2

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 494.22 to 1738.96 | 24 | 1.62e+03 |
| moisture_pp | 731.46 to 1766.46 | 0.178 | 161 |
| temperature_k | 493.11 to 1725.51 | 0.778 | 61.2 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.29 | hexane_rel_percent | 0.0472 | 1.26e-06 | 3.83e-07 | 492.26 to 492.29 | 2.0 | PASS |
| feed | 0.00 to 492.29 | moisture_pp | 0.00264 | 7.45e-08 | 2.27e-07 | 492.26 to 492.29 | 0.05 | PASS |
| feed | 0.00 to 492.29 | temperature_k | 0.0516 | 1.46e-06 | 1.17e-05 | 492.26 to 492.29 | None | no declared goal |
| front | 492.29 to 502.42 | hexane_rel_percent | 24 | 10.8 | 0.0677 | 495.38 to 502.41 | 2.0 | FAIL |
| front | 492.29 to 502.42 | moisture_pp | 0.118 | 0.07 | 0.00439 | 494.25 to 502.41 | 0.05 | FAIL |
| front | 492.29 to 502.42 | temperature_k | 0.778 | 0.406 | 0.0671 | 493.79 to 502.42 | None | no declared goal |
| positive film | 502.42 to 552.71 | hexane_rel_percent | 5.66 | 1.27 | 0.0393 | 502.42 to 542.24 | 2.0 | FAIL |
| positive film | 502.42 to 552.71 | moisture_pp | 0.0416 | 0.00506 | 0.00158 | 502.42 to 549.74 | 0.05 | PASS |
| positive film | 502.42 to 552.71 | temperature_k | 0.529 | 0.0425 | 0.0349 | 502.42 to 514.74 | None | no declared goal |
| absent film | 552.71 to 1766.54 | hexane_rel_percent | 3.33 | 1.19 | 0.893 | 641.46 to 1766.54 | 2.0 | FAIL |
| absent film | 552.71 to 1766.54 | moisture_pp | 0.178 | 0.132 | 0.994 | 743.96 to 1766.46 | 0.05 | FAIL |
| absent film | 552.71 to 1766.54 | temperature_k | 0.0934 | 0.0453 | 0.898 | 582.71 to 1747.71 | None | no declared goal |

## DT mesh pair N16 L2 -> N32 L2

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 493.91 to 1701.46 | 12.4 | 1.77e+03 |
| moisture_pp | 690.28 to 1758.96 | 0.187 | 175 |
| temperature_k | 558.96 to 1766.46 | 0.363 | 67.3 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.29 | hexane_rel_percent | 0.0334 | 9.46e-07 | 2.63e-07 | 492.26 to 492.29 | 2.0 | PASS |
| feed | 0.00 to 492.29 | moisture_pp | 0.00214 | 6.64e-08 | 1.87e-07 | 492.26 to 492.29 | 0.05 | PASS |
| feed | 0.00 to 492.29 | temperature_k | 0.0399 | 1.25e-06 | 9.14e-06 | 492.26 to 492.29 | None | no declared goal |
| front | 492.29 to 502.50 | hexane_rel_percent | 12.4 | 5.62 | 0.0324 | 494.91 to 502.50 | 2.0 | FAIL |
| front | 492.29 to 502.50 | moisture_pp | 0.0576 | 0.036 | 0.0021 | 494.01 to 502.36 | 0.05 | FAIL |
| front | 492.29 to 502.50 | temperature_k | 0.363 | 0.201 | 0.0304 | 493.17 to 502.40 | None | no declared goal |
| positive film | 502.50 to 552.78 | hexane_rel_percent | 3.14 | 0.752 | 0.0214 | 502.50 to 544.92 | 2.0 | FAIL |
| positive film | 502.50 to 552.78 | moisture_pp | 0.0196 | 0.00402 | 0.00115 | 502.50 to 551.17 | 0.05 | PASS |
| positive film | 502.50 to 552.78 | temperature_k | 0.274 | 0.023 | 0.0172 | 502.50 to 516.17 | None | no declared goal |
| absent film | 552.78 to 1766.54 | hexane_rel_percent | 2.68 | 1.38 | 0.946 | 561.53 to 1707.71 | 2.0 | FAIL |
| absent film | 552.78 to 1766.54 | moisture_pp | 0.187 | 0.144 | 0.997 | 682.78 to 1746.46 | 0.05 | FAIL |
| absent film | 552.78 to 1766.54 | temperature_k | 0.157 | 0.0528 | 0.952 | 560.28 to 1717.71 | None | no declared goal |

## DT mesh pair N32 L2 -> N64 L2

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 494.01 to 1649.68 | 5.53 | 1.31e+03 |
| moisture_pp | 604.03 to 1700.28 | 0.153 | 144 |
| temperature_k | 552.78 to 1724.03 | 0.232 | 57.5 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.29 | hexane_rel_percent | 0.00973 | 3.51e-07 | 1.32e-07 | 492.26 to 492.29 | 2.0 | PASS |
| feed | 0.00 to 492.29 | moisture_pp | 0.000857 | 3.57e-08 | 1.22e-07 | 492.26 to 492.29 | 0.05 | PASS |
| feed | 0.00 to 492.29 | temperature_k | 0.0145 | 6.37e-07 | 5.45e-06 | 492.26 to 492.29 | None | no declared goal |
| front | 492.29 to 502.55 | hexane_rel_percent | 5.53 | 2.45 | 0.0192 | 494.87 to 502.55 | 2.0 | FAIL |
| front | 492.29 to 502.55 | moisture_pp | 0.0274 | 0.0163 | 0.00116 | 493.86 to 502.32 | 0.05 | PASS |
| front | 492.29 to 502.55 | temperature_k | 0.155 | 0.0955 | 0.017 | 493.30 to 502.55 | None | no declared goal |
| positive film | 502.55 to 552.18 | hexane_rel_percent | 1.32 | 0.247 | 0.00938 | 502.55 to 550.00 | 2.0 | PASS |
| positive film | 502.55 to 552.18 | moisture_pp | 0.00831 | 0.00205 | 0.000707 | 502.55 to 550.00 | 0.05 | PASS |
| positive film | 502.55 to 552.18 | temperature_k | 0.12 | 0.0105 | 0.00901 | 502.55 to 515.00 | None | no declared goal |
| absent film | 552.18 to 1766.54 | hexane_rel_percent | 3.9 | 1.04 | 0.971 | 552.78 to 1652.78 | 2.0 | FAIL |
| absent film | 552.18 to 1766.54 | moisture_pp | 0.153 | 0.118 | 0.998 | 609.68 to 1702.18 | 0.05 | FAIL |
| absent film | 552.18 to 1766.54 | temperature_k | 0.232 | 0.0462 | 0.974 | 552.78 to 1682.18 | None | no declared goal |

## DT time pair N8 L0 -> N8 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 490.72 to 1529.21 | 8.62 | 197 |
| moisture_pp | 491.06 to 1678.43 | 0.0635 | 3.77 |
| temperature_k | 492.71 to 673.43 | 0.764 | 12.4 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.31 | hexane_rel_percent | 0.11 | 0.000342 | 0.000856 | 183.05 to 492.31 | 0.5 | PASS |
| feed | 0.00 to 492.31 | moisture_pp | 0.00589 | 1.21e-05 | 0.00158 | 490.48 to 492.31 | 0.01 | PASS |
| feed | 0.00 to 492.31 | temperature_k | 0.0124 | 8.7e-05 | 0.00347 | 103.85 to 492.31 | None | no declared goal |
| front | 492.31 to 502.31 | hexane_rel_percent | 5.04 | 1.84 | 0.0937 | 494.60 to 502.31 | 0.5 | FAIL |
| front | 492.31 to 502.31 | moisture_pp | 0.0261 | 0.0115 | 0.0305 | 493.06 to 501.69 | 0.01 | FAIL |
| front | 492.31 to 502.31 | temperature_k | 0.123 | 0.0819 | 0.0663 | 494.11 to 502.30 | None | no declared goal |
| positive film | 502.31 to 553.43 | hexane_rel_percent | 8.62 | 1.92 | 0.498 | 502.43 to 542.31 | 0.5 | FAIL |
| positive film | 502.31 to 553.43 | moisture_pp | 0.0635 | 0.0121 | 0.164 | 502.43 to 544.81 | 0.01 | FAIL |
| positive film | 502.31 to 553.43 | temperature_k | 0.764 | 0.148 | 0.614 | 502.43 to 527.31 | None | no declared goal |
| absent film | 553.43 to 1766.54 | hexane_rel_percent | 0.748 | 0.066 | 0.407 | 553.43 to 1678.43 | 0.5 | FAIL |
| absent film | 553.43 to 1766.54 | moisture_pp | 0.00315 | 0.0025 | 0.804 | 553.43 to 1695.93 | 0.01 | PASS |
| absent film | 553.43 to 1766.54 | temperature_k | 0.0533 | 0.00322 | 0.316 | 553.43 to 1320.93 | None | no declared goal |

## DT time pair N8 L1 -> N8 L2

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 491.35 to 1465.51 | 4.02 | 95.4 |
| moisture_pp | 491.20 to 1680.93 | 0.0325 | 2.09 |
| temperature_k | 492.44 to 669.26 | 0.394 | 6.29 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.29 | hexane_rel_percent | 0.0547 | 0.000168 | 0.000869 | 181.55 to 492.29 | 0.5 | PASS |
| feed | 0.00 to 492.29 | moisture_pp | 0.00334 | 5.92e-06 | 0.0014 | 490.47 to 492.29 | 0.01 | PASS |
| feed | 0.00 to 492.29 | temperature_k | 0.00631 | 4.32e-05 | 0.00339 | 103.55 to 492.29 | None | no declared goal |
| front | 492.29 to 502.24 | hexane_rel_percent | 2.39 | 0.852 | 0.089 | 494.57 to 502.23 | 0.5 | FAIL |
| front | 492.29 to 502.24 | moisture_pp | 0.0116 | 0.00551 | 0.0263 | 493.16 to 501.68 | 0.01 | FAIL |
| front | 492.29 to 502.24 | temperature_k | 0.0818 | 0.0406 | 0.0644 | 494.13 to 502.24 | None | no declared goal |
| positive film | 502.24 to 553.01 | hexane_rel_percent | 4.02 | 0.962 | 0.512 | 502.31 to 542.24 | 0.5 | FAIL |
| positive film | 502.24 to 553.01 | moisture_pp | 0.0325 | 0.00643 | 0.157 | 502.31 to 543.49 | 0.01 | FAIL |
| positive film | 502.24 to 553.01 | temperature_k | 0.394 | 0.0761 | 0.615 | 502.31 to 522.24 | None | no declared goal |
| absent film | 553.01 to 1766.54 | hexane_rel_percent | 0.391 | 0.0313 | 0.398 | 553.01 to 1659.26 | 0.5 | PASS |
| absent film | 553.01 to 1766.54 | moisture_pp | 0.00161 | 0.0014 | 0.816 | 553.43 to 1696.76 | 0.01 | PASS |
| absent film | 553.01 to 1766.54 | temperature_k | 0.0278 | 0.00164 | 0.317 | 553.01 to 1316.76 | None | no declared goal |

## DT time pair N16 L0 -> N16 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 492.84 to 1640.64 | 9.31 | 219 |
| moisture_pp | 491.64 to 1663.14 | 0.0686 | 4.01 |
| temperature_k | 492.26 to 948.14 | 0.815 | 13.1 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.31 | hexane_rel_percent | 0.11 | 0.000343 | 0.000769 | 183.20 to 492.31 | 0.5 | PASS |
| feed | 0.00 to 492.31 | moisture_pp | 0.00622 | 1.21e-05 | 0.00149 | 490.47 to 492.31 | 0.01 | PASS |
| feed | 0.00 to 492.31 | temperature_k | 0.021 | 8.8e-05 | 0.0033 | 104.50 to 492.31 | None | no declared goal |
| front | 492.31 to 502.47 | hexane_rel_percent | 3.77 | 1.34 | 0.0619 | 494.86 to 502.46 | 0.5 | FAIL |
| front | 492.31 to 502.47 | moisture_pp | 0.0151 | 0.00883 | 0.0224 | 493.26 to 502.02 | 0.01 | FAIL |
| front | 492.31 to 502.47 | temperature_k | 0.106 | 0.0695 | 0.0537 | 493.71 to 502.46 | None | no declared goal |
| positive film | 502.47 to 553.14 | hexane_rel_percent | 9.31 | 2.04 | 0.472 | 502.54 to 542.47 | 0.5 | FAIL |
| positive film | 502.47 to 553.14 | moisture_pp | 0.0686 | 0.0129 | 0.163 | 502.54 to 539.97 | 0.01 | FAIL |
| positive film | 502.47 to 553.14 | temperature_k | 0.815 | 0.159 | 0.615 | 502.54 to 527.47 | None | no declared goal |
| absent film | 553.14 to 1766.54 | hexane_rel_percent | 0.772 | 0.084 | 0.465 | 553.14 to 1713.93 | 0.5 | FAIL |
| absent film | 553.14 to 1766.54 | moisture_pp | 0.00347 | 0.00268 | 0.813 | 553.14 to 1680.64 | 0.01 | PASS |
| absent film | 553.14 to 1766.54 | temperature_k | 0.0547 | 0.00355 | 0.328 | 553.14 to 1528.14 | None | no declared goal |

## DT time pair N16 L1 -> N16 L2

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 492.05 to 1647.71 | 4.31 | 113 |
| moisture_pp | 490.91 to 1656.46 | 0.0349 | 2.02 |
| temperature_k | 492.26 to 958.14 | 0.42 | 6.76 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.29 | hexane_rel_percent | 0.0565 | 0.000168 | 0.000736 | 181.68 to 492.29 | 0.5 | PASS |
| feed | 0.00 to 492.29 | moisture_pp | 0.0035 | 5.92e-06 | 0.00144 | 490.47 to 492.29 | 0.01 | PASS |
| feed | 0.00 to 492.29 | temperature_k | 0.0101 | 4.34e-05 | 0.00317 | 103.80 to 492.29 | None | no declared goal |
| front | 492.29 to 502.42 | hexane_rel_percent | 2.23 | 0.759 | 0.0683 | 494.61 to 502.42 | 0.5 | FAIL |
| front | 492.29 to 502.42 | moisture_pp | 0.0112 | 0.00533 | 0.0267 | 493.21 to 501.92 | 0.01 | FAIL |
| front | 492.29 to 502.42 | temperature_k | 0.0805 | 0.041 | 0.0615 | 493.64 to 502.41 | None | no declared goal |
| positive film | 502.42 to 552.71 | hexane_rel_percent | 4.31 | 1.02 | 0.454 | 502.47 to 541.17 | 0.5 | FAIL |
| positive film | 502.42 to 552.71 | moisture_pp | 0.0349 | 0.00682 | 0.17 | 502.47 to 541.17 | 0.01 | FAIL |
| positive film | 502.42 to 552.71 | temperature_k | 0.42 | 0.0815 | 0.607 | 502.47 to 522.42 | None | no declared goal |
| absent film | 552.71 to 1766.54 | hexane_rel_percent | 0.401 | 0.0443 | 0.477 | 552.71 to 1715.21 | 0.5 | PASS |
| absent film | 552.71 to 1766.54 | moisture_pp | 0.00177 | 0.00134 | 0.802 | 552.71 to 1677.71 | 0.01 | PASS |
| absent film | 552.71 to 1766.54 | temperature_k | 0.0286 | 0.00183 | 0.329 | 552.71 to 1528.96 | None | no declared goal |

## DT time pair N32 L0 -> N32 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 493.76 to 1650.72 | 9.6 | 236 |
| moisture_pp | 492.08 to 1653.22 | 0.0713 | 4.94 |
| temperature_k | 492.26 to 1190.72 | 0.835 | 13.9 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.31 | hexane_rel_percent | 0.111 | 0.000343 | 0.000716 | 183.20 to 492.31 | 0.5 | PASS |
| feed | 0.00 to 492.31 | moisture_pp | 0.00663 | 1.21e-05 | 0.00121 | 490.47 to 492.31 | 0.01 | PASS |
| feed | 0.00 to 492.31 | temperature_k | 0.0317 | 8.92e-05 | 0.00316 | 105.15 to 492.31 | None | no declared goal |
| front | 492.31 to 502.54 | hexane_rel_percent | 2.9 | 1.08 | 0.0469 | 495.23 to 502.53 | 0.5 | FAIL |
| front | 492.31 to 502.54 | moisture_pp | 0.013 | 0.00703 | 0.0145 | 493.80 to 502.50 | 0.01 | FAIL |
| front | 492.31 to 502.54 | temperature_k | 0.0924 | 0.0555 | 0.0408 | 493.90 to 502.52 | None | no declared goal |
| positive film | 502.54 to 553.22 | hexane_rel_percent | 9.6 | 2.1 | 0.452 | 502.61 to 542.54 | 0.5 | FAIL |
| positive film | 502.54 to 553.22 | moisture_pp | 0.0713 | 0.0134 | 0.137 | 502.61 to 527.54 | 0.01 | FAIL |
| positive film | 502.54 to 553.22 | temperature_k | 0.835 | 0.163 | 0.596 | 502.61 to 527.54 | None | no declared goal |
| absent film | 553.22 to 1766.54 | hexane_rel_percent | 0.918 | 0.0972 | 0.501 | 553.22 to 1710.72 | 0.5 | FAIL |
| absent film | 553.22 to 1766.54 | moisture_pp | 0.00501 | 0.00345 | 0.847 | 553.22 to 1668.22 | 0.01 | PASS |
| absent film | 553.22 to 1766.54 | temperature_k | 0.0643 | 0.00412 | 0.36 | 553.22 to 1570.72 | None | no declared goal |

## DT time pair N32 L1 -> N32 L2

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 492.94 to 1663.22 | 4.47 | 125 |
| moisture_pp | 490.87 to 1633.22 | 0.0361 | 2.26 |
| temperature_k | 492.26 to 1186.53 | 0.431 | 7.17 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.29 | hexane_rel_percent | 0.0717 | 0.000169 | 0.000664 | 181.78 to 492.29 | 0.5 | PASS |
| feed | 0.00 to 492.29 | moisture_pp | 0.00374 | 5.91e-06 | 0.00129 | 490.47 to 492.29 | 0.01 | PASS |
| feed | 0.00 to 492.29 | temperature_k | 0.0219 | 4.4e-05 | 0.00302 | 104.50 to 492.29 | None | no declared goal |
| front | 492.29 to 502.50 | hexane_rel_percent | 1.76 | 0.649 | 0.053 | 494.83 to 502.50 | 0.5 | FAIL |
| front | 492.29 to 502.50 | moisture_pp | 0.009 | 0.00465 | 0.021 | 493.02 to 502.06 | 0.01 | PASS |
| front | 492.29 to 502.50 | temperature_k | 0.0641 | 0.036 | 0.0513 | 493.49 to 502.49 | None | no declared goal |
| positive film | 502.50 to 552.78 | hexane_rel_percent | 4.47 | 1.04 | 0.419 | 502.54 to 542.50 | 0.5 | FAIL |
| positive film | 502.50 to 552.78 | moisture_pp | 0.0361 | 0.00699 | 0.156 | 502.54 to 537.50 | 0.01 | FAIL |
| positive film | 502.50 to 552.78 | temperature_k | 0.431 | 0.0837 | 0.587 | 502.54 to 522.50 | None | no declared goal |
| absent film | 552.78 to 1766.54 | hexane_rel_percent | 0.475 | 0.0543 | 0.527 | 552.78 to 1714.03 | 0.5 | PASS |
| absent film | 552.78 to 1766.54 | moisture_pp | 0.00235 | 0.00153 | 0.822 | 552.78 to 1655.28 | 0.01 | PASS |
| absent film | 552.78 to 1766.54 | temperature_k | 0.0336 | 0.00212 | 0.359 | 552.78 to 1568.22 | None | no declared goal |

## DT time pair N64 L0 -> N64 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 494.20 to 1650.13 | 9.67 | 252 |
| moisture_pp | 491.64 to 1640.13 | 0.0721 | 5.48 |
| temperature_k | 492.31 to 1242.63 | 0.838 | 14.4 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.31 | hexane_rel_percent | 0.11 | 0.000342 | 0.000667 | 182.90 to 492.31 | 0.5 | PASS |
| feed | 0.00 to 492.31 | moisture_pp | 0.0069 | 1.23e-05 | 0.0011 | 490.48 to 492.31 | 0.01 | PASS |
| feed | 0.00 to 492.31 | temperature_k | 0.0356 | 8.85e-05 | 0.00302 | 104.75 to 492.31 | None | no declared goal |
| front | 492.31 to 502.59 | hexane_rel_percent | 2.01 | 0.795 | 0.0324 | 495.42 to 502.57 | 0.5 | FAIL |
| front | 492.31 to 502.59 | moisture_pp | 0.0104 | 0.00526 | 0.00986 | 493.71 to 502.59 | 0.01 | FAIL |
| front | 492.31 to 502.59 | temperature_k | 0.0661 | 0.0415 | 0.0295 | 494.28 to 502.58 | None | no declared goal |
| positive film | 502.59 to 552.63 | hexane_rel_percent | 9.67 | 2.14 | 0.425 | 502.63 to 542.59 | 0.5 | FAIL |
| positive film | 502.59 to 552.63 | moisture_pp | 0.0721 | 0.0137 | 0.125 | 502.63 to 525.09 | 0.01 | FAIL |
| positive film | 502.59 to 552.63 | temperature_k | 0.838 | 0.166 | 0.575 | 502.63 to 527.59 | None | no declared goal |
| absent film | 552.63 to 1766.54 | hexane_rel_percent | 1.19 | 0.113 | 0.542 | 552.63 to 1705.13 | 0.5 | FAIL |
| absent film | 552.63 to 1766.54 | moisture_pp | 0.00754 | 0.0039 | 0.864 | 552.63 to 1655.13 | 0.01 | PASS |
| absent film | 552.63 to 1766.54 | temperature_k | 0.0823 | 0.00467 | 0.392 | 552.63 to 1552.63 | None | no declared goal |

## DT time pair N64 L1 -> N64 L2

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 493.68 to 1660.93 | 4.49 | 135 |
| moisture_pp | 491.20 to 1617.18 | 0.0365 | 2.55 |
| temperature_k | 492.26 to 1234.68 | 0.433 | 7.5 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 492.29 | hexane_rel_percent | 0.0764 | 0.000169 | 0.000617 | 181.78 to 492.29 | 0.5 | PASS |
| feed | 0.00 to 492.29 | moisture_pp | 0.00395 | 5.92e-06 | 0.00114 | 490.47 to 492.29 | 0.01 | PASS |
| feed | 0.00 to 492.29 | temperature_k | 0.0251 | 4.42e-05 | 0.0029 | 104.78 to 492.29 | None | no declared goal |
| front | 492.29 to 502.55 | hexane_rel_percent | 1.43 | 0.558 | 0.0425 | 495.02 to 502.55 | 0.5 | FAIL |
| front | 492.29 to 502.55 | moisture_pp | 0.00818 | 0.00402 | 0.0162 | 493.42 to 502.37 | 0.01 | PASS |
| front | 492.29 to 502.55 | temperature_k | 0.0596 | 0.0309 | 0.0423 | 493.76 to 502.54 | None | no declared goal |
| positive film | 502.55 to 552.18 | hexane_rel_percent | 4.49 | 1.07 | 0.393 | 502.59 to 541.30 | 0.5 | FAIL |
| positive film | 502.55 to 552.18 | moisture_pp | 0.0365 | 0.0071 | 0.138 | 502.58 to 525.05 | 0.01 | FAIL |
| positive film | 502.55 to 552.18 | temperature_k | 0.433 | 0.0851 | 0.563 | 502.59 to 522.55 | None | no declared goal |
| absent film | 552.18 to 1766.54 | hexane_rel_percent | 0.622 | 0.0625 | 0.564 | 552.18 to 1708.43 | 0.5 | FAIL |
| absent film | 552.18 to 1766.54 | moisture_pp | 0.0038 | 0.00178 | 0.845 | 552.18 to 1637.63 | 0.01 | PASS |
| absent film | 552.18 to 1766.54 | temperature_k | 0.0437 | 0.00242 | 0.392 | 552.18 to 1547.18 | None | no declared goal |

## Faner mesh pair N8 L0 -> N16 L0

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 61.29 to 114.59 | 1.71 | 13.2 |
| moisture_pp | 72.08 to 240.00 | 0.00115 | 0.15 |
| temperature_k | 46.77 to 214.59 | 0.0456 | 1.01 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 47.17 | hexane_rel_percent | 0.0423 | 0.000337 | 0.0012 | 46.77 to 47.17 | 2.0 | PASS |
| feed | 0.00 to 47.17 | moisture_pp | 0.000147 | 9.98e-07 | 0.000314 | 46.77 to 47.17 | 0.05 | PASS |
| feed | 0.00 to 47.17 | temperature_k | 0.0128 | 0.000102 | 0.00475 | 46.77 to 47.17 | None | no declared goal |
| front | 47.17 to 85.59 | hexane_rel_percent | 1.71 | 0.299 | 0.869 | 69.46 to 85.59 | 2.0 | PASS |
| front | 47.17 to 85.59 | moisture_pp | 0.00083 | 0.00025 | 0.0641 | 51.77 to 84.92 | 0.05 | PASS |
| front | 47.17 to 85.59 | temperature_k | 0.0456 | 0.0141 | 0.533 | 60.03 to 85.39 | None | no declared goal |
| dry C | 85.59 to 240.00 | hexane_rel_percent | 0.427 | 0.0111 | 0.13 | 85.59 to 175.59 | 2.0 | PASS |
| dry C | 85.59 to 240.00 | moisture_pp | 0.00115 | 0.000907 | 0.936 | 104.59 to 240.00 | 0.05 | PASS |
| dry C | 85.59 to 240.00 | temperature_k | 0.00757 | 0.00303 | 0.462 | 85.79 to 229.26 | None | no declared goal |

## Faner mesh pair N16 L0 -> N32 L0

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 46.77 to 128.28 | 0.656 | 5.03 |
| moisture_pp | 69.34 to 240.00 | 0.000614 | 0.0347 |
| temperature_k | 46.77 to 207.28 | 0.055 | 0.4 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 46.97 | hexane_rel_percent | 0.18 | 0.000455 | 0.00424 | 46.77 to 46.97 | 2.0 | PASS |
| feed | 0.00 to 46.97 | moisture_pp | 0.000614 | 1.55e-06 | 0.0021 | 46.77 to 46.97 | 0.05 | PASS |
| feed | 0.00 to 46.97 | temperature_k | 0.055 | 0.000139 | 0.0163 | 46.77 to 46.97 | None | no declared goal |
| front | 46.97 to 85.28 | hexane_rel_percent | 0.656 | 0.0983 | 0.748 | 63.08 to 85.28 | 2.0 | PASS |
| front | 46.97 to 85.28 | moisture_pp | 0.000614 | 7.49e-05 | 0.0826 | 48.87 to 85.26 | 0.05 | PASS |
| front | 46.97 to 85.28 | temperature_k | 0.055 | 0.00426 | 0.409 | 46.97 to 84.08 | None | no declared goal |
| dry C | 85.28 to 240.00 | hexane_rel_percent | 0.19 | 0.00806 | 0.248 | 85.28 to 174.59 | 2.0 | PASS |
| dry C | 85.28 to 240.00 | moisture_pp | 0.000279 | 0.000205 | 0.915 | 113.28 to 240.00 | 0.05 | PASS |
| dry C | 85.28 to 240.00 | temperature_k | 0.00435 | 0.00149 | 0.575 | 85.28 to 221.28 | None | no declared goal |

## Faner mesh pair N32 L0 -> N64 L0

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 46.77 to 159.14 | 0.498 | 3.16 |
| moisture_pp | 61.67 to 240.00 | 0.000523 | 0.00856 |
| temperature_k | 46.76 to 204.14 | 0.0461 | 0.296 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 47.17 | hexane_rel_percent | 0.148 | 0.000698 | 0.0104 | 46.77 to 47.17 | 2.0 | PASS |
| feed | 0.00 to 47.17 | moisture_pp | 0.000523 | 2.45e-06 | 0.0135 | 46.77 to 47.17 | 0.05 | PASS |
| feed | 0.00 to 47.17 | temperature_k | 0.0461 | 0.000216 | 0.0344 | 46.77 to 47.17 | None | no declared goal |
| front | 47.17 to 85.14 | hexane_rel_percent | 0.498 | 0.0521 | 0.627 | 68.03 to 85.13 | 2.0 | PASS |
| front | 47.17 to 85.14 | moisture_pp | 0.000179 | 3.33e-05 | 0.148 | 49.30 to 85.11 | 0.05 | PASS |
| front | 47.17 to 85.14 | temperature_k | 0.0156 | 0.00156 | 0.2 | 47.17 to 84.19 | None | no declared goal |
| dry C | 85.14 to 240.00 | hexane_rel_percent | 0.0947 | 0.0074 | 0.363 | 85.15 to 194.14 | 2.0 | PASS |
| dry C | 85.14 to 240.00 | moisture_pp | 6.88e-05 | 4.64e-05 | 0.839 | 100.28 to 240.00 | 0.05 | PASS |
| dry C | 85.14 to 240.00 | temperature_k | 0.00398 | 0.00146 | 0.766 | 85.14 to 211.28 | None | no declared goal |

## Faner mesh pair N4 L1 -> N8 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 65.36 to 112.93 | 5.44 | 34.7 |
| moisture_pp | 86.50 to 240.00 | 0.00487 | 0.668 |
| temperature_k | 65.36 to 234.93 | 0.163 | 2.87 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 46.96 | hexane_rel_percent | 0.111 | 0.000274 | 0.00037 | 46.76 to 46.96 | 2.0 | PASS |
| feed | 0.00 to 46.96 | moisture_pp | 0.000364 | 9.09e-07 | 6.38e-05 | 46.76 to 46.96 | 0.05 | PASS |
| feed | 0.00 to 46.96 | temperature_k | 0.034 | 8.41e-05 | 0.00138 | 46.76 to 46.96 | None | no declared goal |
| front | 46.96 to 86.11 | hexane_rel_percent | 5.44 | 0.802 | 0.904 | 71.98 to 86.05 | 2.0 | FAIL |
| front | 46.96 to 86.11 | moisture_pp | 0.00223 | 0.000827 | 0.0484 | 52.96 to 86.11 | 0.05 | PASS |
| front | 46.96 to 86.11 | temperature_k | 0.163 | 0.0402 | 0.548 | 62.57 to 86.05 | None | no declared goal |
| dry C | 86.11 to 240.00 | hexane_rel_percent | 0.742 | 0.0217 | 0.0959 | 86.11 to 199.93 | 2.0 | PASS |
| dry C | 86.11 to 240.00 | moisture_pp | 0.00487 | 0.00413 | 0.952 | 98.93 to 239.93 | 0.05 | PASS |
| dry C | 86.11 to 240.00 | temperature_k | 0.014 | 0.0084 | 0.45 | 86.97 to 233.43 | None | no declared goal |

## Faner mesh pair N8 L1 -> N16 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 61.29 to 114.51 | 1.7 | 12 |
| moisture_pp | 72.12 to 240.00 | 0.00114 | 0.149 |
| temperature_k | 46.76 to 215.01 | 0.0443 | 0.962 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 46.96 | hexane_rel_percent | 0.0462 | 0.000159 | 0.000624 | 46.76 to 46.96 | 2.0 | PASS |
| feed | 0.00 to 46.96 | moisture_pp | 0.000139 | 5.07e-07 | 0.00016 | 46.76 to 46.96 | 0.05 | PASS |
| feed | 0.00 to 46.96 | temperature_k | 0.0141 | 4.83e-05 | 0.00235 | 46.76 to 46.96 | None | no declared goal |
| front | 46.96 to 85.51 | hexane_rel_percent | 1.7 | 0.27 | 0.867 | 68.89 to 85.49 | 2.0 | PASS |
| front | 46.96 to 85.51 | moisture_pp | 0.0008 | 0.000241 | 0.0624 | 49.96 to 83.17 | 0.05 | PASS |
| front | 46.96 to 85.51 | temperature_k | 0.0443 | 0.0134 | 0.538 | 59.29 to 85.31 | None | no declared goal |
| dry C | 85.51 to 240.00 | hexane_rel_percent | 0.286 | 0.0102 | 0.132 | 85.51 to 182.51 | 2.0 | PASS |
| dry C | 85.51 to 240.00 | moisture_pp | 0.00114 | 0.000904 | 0.937 | 105.11 to 240.00 | 0.05 | PASS |
| dry C | 85.51 to 240.00 | temperature_k | 0.00665 | 0.00286 | 0.46 | 85.65 to 229.51 | None | no declared goal |

## Faner mesh pair N16 L1 -> N32 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 55.53 to 130.51 | 0.545 | 4.28 |
| moisture_pp | 76.51 to 240.00 | 0.000272 | 0.0331 |
| temperature_k | 46.76 to 207.51 | 0.0099 | 0.359 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 46.96 | hexane_rel_percent | 0.0291 | 9.74e-05 | 0.00107 | 46.76 to 46.96 | 2.0 | PASS |
| feed | 0.00 to 46.96 | moisture_pp | 9.92e-05 | 3.01e-07 | 0.000426 | 46.76 to 46.96 | 0.05 | PASS |
| feed | 0.00 to 46.96 | temperature_k | 0.00857 | 2.84e-05 | 0.00371 | 46.76 to 46.96 | None | no declared goal |
| front | 46.96 to 85.24 | hexane_rel_percent | 0.545 | 0.0874 | 0.781 | 64.57 to 85.24 | 2.0 | PASS |
| front | 46.96 to 85.24 | moisture_pp | 0.00019 | 6.75e-05 | 0.078 | 51.98 to 85.18 | 0.05 | PASS |
| front | 46.96 to 85.24 | temperature_k | 0.0099 | 0.00372 | 0.397 | 54.16 to 85.11 | None | no declared goal |
| dry C | 85.24 to 240.00 | hexane_rel_percent | 0.134 | 0.00603 | 0.218 | 85.24 to 161.51 | 2.0 | PASS |
| dry C | 85.24 to 240.00 | moisture_pp | 0.000272 | 0.000197 | 0.922 | 116.51 to 240.00 | 0.05 | PASS |
| dry C | 85.24 to 240.00 | temperature_k | 0.00373 | 0.00139 | 0.6 | 85.26 to 221.01 | None | no declared goal |

## Faner mesh pair N32 L1 -> N64 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 46.76 to 140.65 | 0.204 | 1.39 |
| moisture_pp | 74.22 to 240.00 | 7.91e-05 | 0.00738 |
| temperature_k | 46.76 to 203.15 | 0.00479 | 0.122 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 46.96 | hexane_rel_percent | 0.0165 | 4.63e-05 | 0.00157 | 46.76 to 46.96 | 2.0 | PASS |
| feed | 0.00 to 46.96 | moisture_pp | 5.52e-05 | 1.41e-07 | 0.000898 | 46.76 to 46.96 | 0.05 | PASS |
| feed | 0.00 to 46.96 | temperature_k | 0.00479 | 1.3e-05 | 0.00503 | 46.76 to 46.96 | None | no declared goal |
| front | 46.96 to 85.15 | hexane_rel_percent | 0.204 | 0.0253 | 0.695 | 60.36 to 85.15 | 2.0 | PASS |
| front | 46.96 to 85.15 | moisture_pp | 7.91e-05 | 2.17e-05 | 0.112 | 50.91 to 85.15 | 0.05 | PASS |
| front | 46.96 to 85.15 | temperature_k | 0.0031 | 0.000893 | 0.281 | 50.21 to 85.15 | None | no declared goal |
| dry C | 85.15 to 240.00 | hexane_rel_percent | 0.0357 | 0.00272 | 0.304 | 85.15 to 175.15 | 2.0 | PASS |
| dry C | 85.15 to 240.00 | moisture_pp | 6.25e-05 | 4.23e-05 | 0.887 | 117.65 to 240.00 | 0.05 | PASS |
| dry C | 85.15 to 240.00 | temperature_k | 0.00158 | 0.000561 | 0.714 | 85.18 to 213.15 | None | no declared goal |

## Faner mesh pair N8 L2 -> N16 L2

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 61.23 to 116.03 | 1.7 | 11.9 |
| moisture_pp | 72.29 to 240.00 | 0.00114 | 0.149 |
| temperature_k | 46.76 to 214.78 | 0.0438 | 0.987 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 46.86 | hexane_rel_percent | 0.0561 | 7.79e-05 | 0.000306 | 46.76 to 46.86 | 2.0 | PASS |
| feed | 0.00 to 46.86 | moisture_pp | 0.000185 | 2.6e-07 | 8.2e-05 | 46.76 to 46.86 | 0.05 | PASS |
| feed | 0.00 to 46.86 | temperature_k | 0.0171 | 2.36e-05 | 0.00112 | 46.76 to 46.86 | None | no declared goal |
| front | 46.86 to 85.44 | hexane_rel_percent | 1.7 | 0.265 | 0.856 | 68.77 to 85.42 | 2.0 | PASS |
| front | 46.86 to 85.44 | moisture_pp | 0.000821 | 0.000239 | 0.062 | 50.16 to 83.55 | 0.05 | PASS |
| front | 46.86 to 85.44 | temperature_k | 0.0438 | 0.0133 | 0.52 | 58.91 to 85.29 | None | no declared goal |
| dry C | 85.44 to 240.00 | hexane_rel_percent | 0.261 | 0.0111 | 0.143 | 85.44 to 175.69 | 2.0 | PASS |
| dry C | 85.44 to 240.00 | moisture_pp | 0.00114 | 0.000901 | 0.938 | 105.78 to 240.00 | 0.05 | PASS |
| dry C | 85.44 to 240.00 | temperature_k | 0.00712 | 0.00306 | 0.479 | 85.44 to 228.53 | None | no declared goal |

## Faner mesh pair N16 L2 -> N32 L2

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 54.97 to 121.94 | 0.453 | 3.5 |
| moisture_pp | 76.70 to 240.00 | 0.000268 | 0.0326 |
| temperature_k | 46.76 to 207.44 | 0.00918 | 0.291 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 46.86 | hexane_rel_percent | 0.0222 | 4.6e-05 | 0.000616 | 46.76 to 46.86 | 2.0 | PASS |
| feed | 0.00 to 46.86 | moisture_pp | 7.53e-05 | 1.47e-07 | 0.000212 | 46.76 to 46.86 | 0.05 | PASS |
| feed | 0.00 to 46.86 | temperature_k | 0.00647 | 1.34e-05 | 0.00217 | 46.76 to 46.86 | None | no declared goal |
| front | 46.86 to 85.21 | hexane_rel_percent | 0.453 | 0.0742 | 0.813 | 63.71 to 85.20 | 2.0 | PASS |
| front | 46.86 to 85.21 | moisture_pp | 0.000208 | 6.26e-05 | 0.0737 | 51.56 to 85.09 | 0.05 | PASS |
| front | 46.86 to 85.21 | temperature_k | 0.00918 | 0.00347 | 0.459 | 53.78 to 85.03 | None | no declared goal |
| dry C | 85.21 to 240.00 | hexane_rel_percent | 0.0838 | 0.00422 | 0.187 | 85.21 to 149.69 | 2.0 | PASS |
| dry C | 85.21 to 240.00 | moisture_pp | 0.000268 | 0.000195 | 0.926 | 116.46 to 239.94 | 0.05 | PASS |
| dry C | 85.21 to 240.00 | temperature_k | 0.00268 | 0.00101 | 0.539 | 85.24 to 223.46 | None | no declared goal |

## Faner time pair N8 L0 -> N8 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 78.88 to 230.11 | 0.739 | 40.8 |
| moisture_pp | 97.26 to 240.00 | 0.000922 | 0.0728 |
| temperature_k | 97.61 to 238.11 | 0.0736 | 8.65 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 46.96 | hexane_rel_percent | 0.155 | 0.00041 | 0.000471 | 26.88 to 46.96 | 0.5 | PASS |
| feed | 0.00 to 46.96 | moisture_pp | 0.000546 | 1.55e-06 | 0.000998 | 16.25 to 46.96 | 0.01 | PASS |
| feed | 0.00 to 46.96 | temperature_k | 0.0477 | 0.000111 | 0.000604 | 46.77 to 46.96 | None | no declared goal |
| front | 46.96 to 86.11 | hexane_rel_percent | 0.739 | 0.0905 | 0.0868 | 69.05 to 86.11 | 0.5 | FAIL |
| front | 46.96 to 86.11 | moisture_pp | 0.000546 | 6.08e-05 | 0.0327 | 46.96 to 84.77 | 0.01 | PASS |
| front | 46.96 to 86.11 | temperature_k | 0.0477 | 0.00243 | 0.011 | 46.96 to 85.13 | None | no declared goal |
| dry C | 86.11 to 240.00 | hexane_rel_percent | 0.339 | 0.242 | 0.913 | 87.61 to 227.26 | 0.5 | PASS |
| dry C | 86.11 to 240.00 | moisture_pp | 0.000922 | 0.000457 | 0.966 | 108.61 to 240.00 | 0.01 | PASS |
| dry C | 86.11 to 240.00 | temperature_k | 0.0736 | 0.0555 | 0.988 | 96.61 to 234.61 | None | no declared goal |

## Faner time pair N8 L1 -> N8 L2

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 78.51 to 230.28 | 0.321 | 20.3 |
| moisture_pp | 98.11 to 240.00 | 0.000463 | 0.0365 |
| temperature_k | 97.11 to 237.61 | 0.0369 | 4.34 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 46.86 | hexane_rel_percent | 0.0956 | 0.00012 | 0.000278 | 30.12 to 46.86 | 0.5 | PASS |
| feed | 0.00 to 46.86 | moisture_pp | 0.000339 | 4.51e-07 | 0.000579 | 18.69 to 46.86 | 0.01 | PASS |
| feed | 0.00 to 46.86 | temperature_k | 0.0294 | 3.32e-05 | 0.000359 | 46.76 to 46.86 | None | no declared goal |
| front | 46.86 to 86.03 | hexane_rel_percent | 0.321 | 0.0431 | 0.0833 | 64.13 to 86.03 | 0.5 | PASS |
| front | 46.86 to 86.03 | moisture_pp | 0.000339 | 3.02e-05 | 0.0324 | 46.86 to 84.27 | 0.01 | PASS |
| front | 46.86 to 86.03 | temperature_k | 0.0294 | 0.0012 | 0.0108 | 46.86 to 85.13 | None | no declared goal |
| dry C | 86.03 to 240.00 | hexane_rel_percent | 0.169 | 0.121 | 0.916 | 88.53 to 228.11 | 0.5 | PASS |
| dry C | 86.03 to 240.00 | moisture_pp | 0.000463 | 0.000229 | 0.967 | 108.78 to 240.00 | 0.01 | PASS |
| dry C | 86.03 to 240.00 | temperature_k | 0.0369 | 0.0279 | 0.989 | 96.53 to 234.61 | None | no declared goal |

## Faner time pair N16 L0 -> N16 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 78.65 to 230.01 | 0.463 | 39.6 |
| moisture_pp | 99.01 to 240.00 | 0.000923 | 0.0726 |
| temperature_k | 97.59 to 237.51 | 0.0734 | 8.6 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 46.96 | hexane_rel_percent | 0.162 | 0.000454 | 0.000539 | 29.00 to 46.96 | 0.5 | PASS |
| feed | 0.00 to 46.96 | moisture_pp | 0.000568 | 1.7e-06 | 0.0011 | 17.75 to 46.96 | 0.01 | PASS |
| feed | 0.00 to 46.96 | temperature_k | 0.0499 | 0.000125 | 0.000683 | 46.77 to 46.96 | None | no declared goal |
| front | 46.96 to 85.51 | hexane_rel_percent | 0.463 | 0.062 | 0.0603 | 50.37 to 85.50 | 0.5 | PASS |
| front | 46.96 to 85.51 | moisture_pp | 0.000568 | 4.9e-05 | 0.026 | 46.96 to 83.91 | 0.01 | PASS |
| front | 46.96 to 85.51 | temperature_k | 0.0499 | 0.00181 | 0.0081 | 46.96 to 84.31 | None | no declared goal |
| dry C | 85.51 to 240.00 | hexane_rel_percent | 0.339 | 0.241 | 0.939 | 86.59 to 227.01 | 0.5 | PASS |
| dry C | 85.51 to 240.00 | moisture_pp | 0.000923 | 0.000457 | 0.973 | 107.59 to 240.00 | 0.01 | PASS |
| dry C | 85.51 to 240.00 | temperature_k | 0.0734 | 0.0552 | 0.991 | 97.01 to 235.01 | None | no declared goal |

## Faner time pair N16 L1 -> N16 L2

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 78.51 to 229.69 | 0.337 | 20.2 |
| moisture_pp | 98.19 to 240.00 | 0.000464 | 0.0367 |
| temperature_k | 96.44 to 236.94 | 0.0372 | 4.37 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 46.86 | hexane_rel_percent | 0.115 | 0.000152 | 0.000351 | 35.19 to 46.86 | 0.5 | PASS |
| feed | 0.00 to 46.86 | moisture_pp | 0.000406 | 5.61e-07 | 0.000716 | 22.69 to 46.86 | 0.01 | PASS |
| feed | 0.00 to 46.86 | temperature_k | 0.0354 | 4.28e-05 | 0.000459 | 46.76 to 46.86 | None | no declared goal |
| front | 46.86 to 85.44 | hexane_rel_percent | 0.337 | 0.0381 | 0.0726 | 56.93 to 85.44 | 0.5 | PASS |
| front | 46.86 to 85.44 | moisture_pp | 0.000406 | 2.7e-05 | 0.0284 | 46.86 to 84.31 | 0.01 | PASS |
| front | 46.86 to 85.44 | temperature_k | 0.0354 | 0.00101 | 0.00889 | 46.86 to 84.36 | None | no declared goal |
| dry C | 85.44 to 240.00 | hexane_rel_percent | 0.17 | 0.121 | 0.927 | 87.94 to 228.01 | 0.5 | PASS |
| dry C | 85.44 to 240.00 | moisture_pp | 0.000464 | 0.000231 | 0.971 | 107.19 to 240.00 | 0.01 | PASS |
| dry C | 85.44 to 240.00 | temperature_k | 0.0372 | 0.028 | 0.991 | 96.51 to 234.94 | None | no declared goal |

## Faner time pair N32 L0 -> N32 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 79.48 to 229.28 | 0.379 | 39.1 |
| moisture_pp | 100.28 to 240.00 | 0.000919 | 0.0721 |
| temperature_k | 95.28 to 234.74 | 0.0733 | 8.56 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 46.96 | hexane_rel_percent | 0.0361 | 0.000131 | 0.000158 | 10.50 to 46.96 | 0.5 | PASS |
| feed | 0.00 to 46.96 | moisture_pp | 0.000128 | 5.66e-07 | 0.000369 | 6.25 to 46.96 | 0.01 | PASS |
| feed | 0.00 to 46.96 | temperature_k | 0.0111 | 2.55e-05 | 0.00014 | 46.77 to 46.96 | None | no declared goal |
| front | 46.96 to 85.24 | hexane_rel_percent | 0.379 | 0.0509 | 0.0498 | 66.40 to 85.24 | 0.5 | PASS |
| front | 46.96 to 85.24 | moisture_pp | 0.000114 | 3.87e-05 | 0.0205 | 47.36 to 83.99 | 0.01 | PASS |
| front | 46.96 to 85.24 | temperature_k | 0.0105 | 0.00124 | 0.00554 | 46.96 to 84.50 | None | no declared goal |
| dry C | 85.24 to 240.00 | hexane_rel_percent | 0.339 | 0.24 | 0.95 | 87.28 to 227.74 | 0.5 | PASS |
| dry C | 85.24 to 240.00 | moisture_pp | 0.000919 | 0.000456 | 0.979 | 106.28 to 240.00 | 0.01 | PASS |
| dry C | 85.24 to 240.00 | temperature_k | 0.0733 | 0.055 | 0.994 | 98.28 to 236.24 | None | no declared goal |

## Faner time pair N32 L1 -> N32 L2

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 79.98 to 230.71 | 0.203 | 19.4 |
| moisture_pp | 100.24 to 240.00 | 0.000462 | 0.0363 |
| temperature_k | 95.74 to 235.46 | 0.0367 | 4.3 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 46.86 | hexane_rel_percent | 0.113 | 0.000157 | 0.000379 | 36.00 to 46.86 | 0.5 | PASS |
| feed | 0.00 to 46.86 | moisture_pp | 0.000397 | 5.79e-07 | 0.000748 | 23.25 to 46.86 | 0.01 | PASS |
| feed | 0.00 to 46.86 | temperature_k | 0.0347 | 4.45e-05 | 0.000485 | 46.76 to 46.86 | None | no declared goal |
| front | 46.86 to 85.21 | hexane_rel_percent | 0.203 | 0.025 | 0.0493 | 48.56 to 85.17 | 0.5 | PASS |
| front | 46.86 to 85.21 | moisture_pp | 0.000397 | 2.13e-05 | 0.0225 | 46.86 to 83.61 | 0.01 | PASS |
| front | 46.86 to 85.21 | temperature_k | 0.0347 | 0.000753 | 0.00672 | 46.86 to 83.82 | None | no declared goal |
| dry C | 85.21 to 240.00 | hexane_rel_percent | 0.168 | 0.119 | 0.95 | 89.24 to 229.21 | 0.5 | PASS |
| dry C | 85.21 to 240.00 | moisture_pp | 0.000462 | 0.000229 | 0.977 | 106.96 to 239.96 | 0.01 | PASS |
| dry C | 85.21 to 240.00 | temperature_k | 0.0367 | 0.0276 | 0.993 | 97.46 to 235.46 | None | no declared goal |

## Faner time pair N64 L0 -> N64 L1

| Error | 95 % window (s) | Max | Integral |
|---|---|---:|---:|
| hexane_rel_percent | 86.65 to 234.14 | 0.332 | 37.4 |
| moisture_pp | 102.14 to 240.00 | 0.000915 | 0.0712 |
| temperature_k | 96.15 to 235.14 | 0.0723 | 8.42 |

| Phase (fine grid) | Span (s) | Error | Max | Time mean | Share | 95 % window (s) | Goal | Verdict |
|---|---|---|---:|---:|---:|---|---:|---|
| feed | 0.00 to 46.96 | hexane_rel_percent | 0.151 | 0.000438 | 0.00055 | 28.25 to 46.96 | 0.5 | PASS |
| feed | 0.00 to 46.96 | moisture_pp | 0.000525 | 1.63e-06 | 0.00108 | 17.12 to 46.96 | 0.01 | PASS |
| feed | 0.00 to 46.96 | temperature_k | 0.0466 | 0.00012 | 0.00067 | 46.77 to 46.96 | None | no declared goal |
| front | 46.96 to 85.15 | hexane_rel_percent | 0.151 | 0.0251 | 0.0257 | 46.96 to 83.81 | 0.5 | PASS |
| front | 46.96 to 85.15 | moisture_pp | 0.000525 | 2.93e-05 | 0.0157 | 46.96 to 81.66 | 0.01 | PASS |
| front | 46.96 to 85.15 | temperature_k | 0.0466 | 0.00118 | 0.00535 | 46.96 to 84.32 | None | no declared goal |
| dry C | 85.15 to 240.00 | hexane_rel_percent | 0.332 | 0.235 | 0.974 | 86.65 to 227.14 | 0.5 | PASS |
| dry C | 85.15 to 240.00 | moisture_pp | 0.000915 | 0.000452 | 0.983 | 106.65 to 240.00 | 0.01 | PASS |
| dry C | 85.15 to 240.00 | temperature_k | 0.0723 | 0.0541 | 0.994 | 97.65 to 235.14 | None | no declared goal |

## Transition quantities (DT)

| Ladder | Matched | Grids | Quantity | Values | Successive differences | Observed orders |
|---|---|---|---|---|---|---|
| mesh | L1 | N8 L1, N16 L1, N32 L1, N64 L1 | film-depletion time (s) | [553.4271016, 553.1377394, 553.2186507, 552.6290154] | [0.289, 0.0809, 0.59] | [1.838, -2.865] |
| mesh | L1 | N8 L1, N16 L1, N32 L1, N64 L1 | cumulative net exterior water flux to depletion (kg/m2) | [-0.04325627213, -0.04325826489, -0.04326299729, -0.04330716263] | [1.99e-06, 4.73e-06, 4.42e-05] | [-1.248, -3.222] |
| mesh | L1 | N8 L1, N16 L1, N32 L1, N64 L1 | surface temperature at depletion (K) | [371.7404107, 371.7401246, 371.7401926, 371.7396351] | [0.000286, 6.79e-05, 0.000557] | [2.074, -3.037] |
| mesh | L1 | N8 L1, N16 L1, N32 L1, N64 L1 | outermost-cell retained water at depletion (kg/kg dry) | [0.2906283184, 0.319590975, 0.3361662227, 0.3463892075] | [0.029, 0.0166, 0.0102] | [0.805, 0.697] |
| mesh | L0 | N8 L0, N16 L0, N32 L0, N64 L0 | film-depletion time (s) | [554.2145083, 553.9349761, 554.0360945, 553.4624711] | [0.28, 0.101, 0.574] | [1.467, -2.504] |
| mesh | L0 | N8 L0, N16 L0, N32 L0, N64 L0 | cumulative net exterior water flux to depletion (kg/m2) | [-0.04268404917, -0.04267825924, -0.0426835161, -0.04321363322] | [5.79e-06, 5.26e-06, 0.00053] | [0.139, -6.656] |
| mesh | L0 | N8 L0, N16 L0, N32 L0, N64 L0 | surface temperature at depletion (K) | [371.7411383, 371.7408598, 371.7409467, 371.7404023] | [0.000278, 8.68e-05, 0.000544] | [1.681, -2.648] |
| mesh | L0 | N8 L0, N16 L0, N32 L0, N64 L0 | outermost-cell retained water at depletion (kg/kg dry) | [0.2903946228, 0.3192223513, 0.3357450334, 0.3459428831] | [0.0288, 0.0165, 0.0102] | [0.803, 0.696] |
| mesh | L2 | N8 L2, N16 L2, N32 L2, N64 L2 | film-depletion time (s) | [553.0060048, 552.7114694, 552.7803063, 552.1757012] | [0.295, 0.0688, 0.605] | [2.097, -3.135] |
| mesh | L2 | N8 L2, N16 L2, N32 L2, N64 L2 | cumulative net exterior water flux to depletion (kg/m2) | [-0.04354876206, -0.04356453453, -0.0435687923, -0.04361233211] | [1.58e-05, 4.26e-06, 4.35e-05] | [1.889, -3.354] |
| mesh | L2 | N8 L2, N16 L2, N32 L2, N64 L2 | surface temperature at depletion (K) | [371.7400193, 371.7397288, 371.7397854, 371.7392129] | [0.00029, 5.66e-05, 0.000572] | [2.36, -3.339] |
| mesh | L2 | N8 L2, N16 L2, N32 L2, N64 L2 | outermost-cell retained water at depletion (kg/kg dry) | [0.2907475428, 0.3197819886, 0.3363843798, 0.3466348205] | [0.029, 0.0166, 0.0103] | [0.806, 0.696] |
| time | N8 | N8 L0, N8 L1, N8 L2 | film-depletion time (s) | [554.2145083, 553.4271016, 553.0060048] | [0.787, 0.421] | [0.903] |
| time | N8 | N8 L0, N8 L1, N8 L2 | cumulative net exterior water flux to depletion (kg/m2) | [-0.04268404917, -0.04325627213, -0.04354876206] | [0.000572, 0.000292] | [0.968] |
| time | N8 | N8 L0, N8 L1, N8 L2 | surface temperature at depletion (K) | [371.7411383, 371.7404107, 371.7400193] | [0.000728, 0.000391] | [0.894] |
| time | N8 | N8 L0, N8 L1, N8 L2 | outermost-cell retained water at depletion (kg/kg dry) | [0.2903946228, 0.2906283184, 0.2907475428] | [0.000234, 0.000119] | [0.971] |
| time | N16 | N16 L0, N16 L1, N16 L2 | film-depletion time (s) | [553.9349761, 553.1377394, 552.7114694] | [0.797, 0.426] | [0.903] |
| time | N16 | N16 L0, N16 L1, N16 L2 | cumulative net exterior water flux to depletion (kg/m2) | [-0.04267825924, -0.04325826489, -0.04356453453] | [0.00058, 0.000306] | [0.921] |
| time | N16 | N16 L0, N16 L1, N16 L2 | surface temperature at depletion (K) | [371.7408598, 371.7401246, 371.7397288] | [0.000735, 0.000396] | [0.893] |
| time | N16 | N16 L0, N16 L1, N16 L2 | outermost-cell retained water at depletion (kg/kg dry) | [0.3192223513, 0.319590975, 0.3197819886] | [0.000369, 0.000191] | [0.948] |
| time | N32 | N32 L0, N32 L1, N32 L2 | film-depletion time (s) | [554.0360945, 553.2186507, 552.7803063] | [0.817, 0.438] | [0.899] |
| time | N32 | N32 L0, N32 L1, N32 L2 | cumulative net exterior water flux to depletion (kg/m2) | [-0.0426835161, -0.04326299729, -0.0435687923] | [0.000579, 0.000306] | [0.922] |
| time | N32 | N32 L0, N32 L1, N32 L2 | surface temperature at depletion (K) | [371.7409467, 371.7401926, 371.7397854] | [0.000754, 0.000407] | [0.889] |
| time | N32 | N32 L0, N32 L1, N32 L2 | outermost-cell retained water at depletion (kg/kg dry) | [0.3357450334, 0.3361662227, 0.3363843798] | [0.000421, 0.000218] | [0.949] |
| time | N64 | N64 L0, N64 L1, N64 L2 | film-depletion time (s) | [553.4624711, 552.6290154, 552.1757012] | [0.833, 0.453] | [0.879] |
| time | N64 | N64 L0, N64 L1, N64 L2 | cumulative net exterior water flux to depletion (kg/m2) | [-0.04321363322, -0.04330716263, -0.04361233211] | [9.35e-05, 0.000305] | [-1.706] |
| time | N64 | N64 L0, N64 L1, N64 L2 | surface temperature at depletion (K) | [371.7404023, 371.7396351, 371.7392129] | [0.000767, 0.000422] | [0.862] |
| time | N64 | N64 L0, N64 L1, N64 L2 | outermost-cell retained water at depletion (kg/kg dry) | [0.3459428831, 0.3463892075, 0.3466348205] | [0.000446, 0.000246] | [0.862] |

## Phase time-mean orders

| Study | Ladder | Matched | Phase | Error | Pairs | Time means | Orders |
|---|---|---|---|---|---|---|---|
| DT | mesh | L0 | feed | hexane_rel_percent | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [8.99e-06, 3.34e-06, 1.65e-06] | [1.427, 1.016] |
| DT | mesh | L0 | front | hexane_rel_percent | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [10.4, 5.32, 2.09] | [0.965, 1.345] |
| DT | mesh | L0 | positive film | hexane_rel_percent | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [1.37, 0.803, 0.251] | [0.766, 1.68] |
| DT | mesh | L0 | absent film | hexane_rel_percent | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [1.2, 1.39, 1.05] | [-0.204, 0.401] |
| DT | mesh | L0 | feed | moisture_pp | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [5.22e-07, 2.93e-07, 2.21e-07] | [0.834, 0.403] |
| DT | mesh | L0 | front | moisture_pp | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [0.0676, 0.0341, 0.0141] | [0.99, 1.271] |
| DT | mesh | L0 | positive film | moisture_pp | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [0.00504, 0.00323, 0.00135] | [0.643, 1.255] |
| DT | mesh | L0 | absent film | moisture_pp | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [0.132, 0.143, 0.118] | [-0.113, 0.282] |
| DT | mesh | L0 | feed | temperature_k | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [1e-05, 5.04e-06, 3.39e-06] | [0.987, 0.574] |
| DT | mesh | L0 | front | temperature_k | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [0.389, 0.189, 0.0826] | [1.037, 1.198] |
| DT | mesh | L0 | positive film | temperature_k | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [0.0543, 0.0277, 0.0108] | [0.971, 1.361] |
| DT | mesh | L0 | absent film | temperature_k | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [0.0454, 0.0527, 0.046] | [-0.216, 0.195] |
| DT | mesh | L1 | feed | hexane_rel_percent | N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [3.77e-06, 1.95e-06, 5.37e-07] | [0.953, 1.858] |
| DT | mesh | L1 | front | hexane_rel_percent | N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [10.8, 5.53, 2.37] | [0.96, 1.225] |
| DT | mesh | L1 | positive film | hexane_rel_percent | N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [1.3, 0.768, 0.247] | [0.754, 1.634] |
| DT | mesh | L1 | absent film | hexane_rel_percent | N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [1.2, 1.38, 1.05] | [-0.209, 0.403] |
| DT | mesh | L1 | feed | moisture_pp | N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [2.19e-07, 1.48e-07, 7.37e-08] | [0.567, 1.004] |
| DT | mesh | L1 | front | moisture_pp | N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [0.0696, 0.0353, 0.0158] | [0.98, 1.161] |
| DT | mesh | L1 | positive film | moisture_pp | N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [0.00505, 0.00379, 0.00177] | [0.414, 1.101] |
| DT | mesh | L1 | absent film | moisture_pp | N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [0.132, 0.144, 0.118] | [-0.119, 0.285] |
| DT | mesh | L1 | feed | temperature_k | N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [4.25e-06, 2.69e-06, 1.21e-06] | [0.66, 1.149] |
| DT | mesh | L1 | front | temperature_k | N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [0.402, 0.197, 0.0926] | [1.031, 1.086] |
| DT | mesh | L1 | positive film | temperature_k | N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [0.0464, 0.0246, 0.0105] | [0.913, 1.224] |
| DT | mesh | L1 | absent film | temperature_k | N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [0.0453, 0.0528, 0.0461] | [-0.219, 0.194] |
| DT | mesh | L2 | feed | hexane_rel_percent | N8 L2->N16 L2, N16 L2->N32 L2, N32 L2->N64 L2 | [1.26e-06, 9.46e-07, 3.51e-07] | [0.416, 1.429] |
| DT | mesh | L2 | front | hexane_rel_percent | N8 L2->N16 L2, N16 L2->N32 L2, N32 L2->N64 L2 | [10.8, 5.62, 2.45] | [0.945, 1.199] |
| DT | mesh | L2 | positive film | hexane_rel_percent | N8 L2->N16 L2, N16 L2->N32 L2, N32 L2->N64 L2 | [1.27, 0.752, 0.247] | [0.751, 1.607] |
| DT | mesh | L2 | absent film | hexane_rel_percent | N8 L2->N16 L2, N16 L2->N32 L2, N32 L2->N64 L2 | [1.19, 1.38, 1.04] | [-0.211, 0.402] |
| DT | mesh | L2 | feed | moisture_pp | N8 L2->N16 L2, N16 L2->N32 L2, N32 L2->N64 L2 | [7.45e-08, 6.64e-08, 3.57e-08] | [0.165, 0.897] |
| DT | mesh | L2 | front | moisture_pp | N8 L2->N16 L2, N16 L2->N32 L2, N32 L2->N64 L2 | [0.07, 0.036, 0.0163] | [0.958, 1.146] |
| DT | mesh | L2 | positive film | moisture_pp | N8 L2->N16 L2, N16 L2->N32 L2, N32 L2->N64 L2 | [0.00506, 0.00402, 0.00205] | [0.333, 0.971] |
| DT | mesh | L2 | absent film | moisture_pp | N8 L2->N16 L2, N16 L2->N32 L2, N32 L2->N64 L2 | [0.132, 0.144, 0.118] | [-0.121, 0.284] |
| DT | mesh | L2 | feed | temperature_k | N8 L2->N16 L2, N16 L2->N32 L2, N32 L2->N64 L2 | [1.46e-06, 1.25e-06, 6.37e-07] | [0.222, 0.972] |
| DT | mesh | L2 | front | temperature_k | N8 L2->N16 L2, N16 L2->N32 L2, N32 L2->N64 L2 | [0.406, 0.201, 0.0955] | [1.016, 1.07] |
| DT | mesh | L2 | positive film | temperature_k | N8 L2->N16 L2, N16 L2->N32 L2, N32 L2->N64 L2 | [0.0425, 0.023, 0.0105] | [0.886, 1.14] |
| DT | mesh | L2 | absent film | temperature_k | N8 L2->N16 L2, N16 L2->N32 L2, N32 L2->N64 L2 | [0.0453, 0.0528, 0.0462] | [-0.221, 0.194] |
| DT | time | N8 | feed | hexane_rel_percent | N8 L0->N8 L1, N8 L1->N8 L2 | [0.000342, 0.000168] | [1.023] |
| DT | time | N8 | front | hexane_rel_percent | N8 L0->N8 L1, N8 L1->N8 L2 | [1.84, 0.852] | [1.113] |
| DT | time | N8 | positive film | hexane_rel_percent | N8 L0->N8 L1, N8 L1->N8 L2 | [1.92, 0.962] | [0.995] |
| DT | time | N8 | absent film | hexane_rel_percent | N8 L0->N8 L1, N8 L1->N8 L2 | [0.066, 0.0313] | [1.078] |
| DT | time | N8 | feed | moisture_pp | N8 L0->N8 L1, N8 L1->N8 L2 | [1.21e-05, 5.92e-06] | [1.035] |
| DT | time | N8 | front | moisture_pp | N8 L0->N8 L1, N8 L1->N8 L2 | [0.0115, 0.00551] | [1.064] |
| DT | time | N8 | positive film | moisture_pp | N8 L0->N8 L1, N8 L1->N8 L2 | [0.0121, 0.00643] | [0.914] |
| DT | time | N8 | absent film | moisture_pp | N8 L0->N8 L1, N8 L1->N8 L2 | [0.0025, 0.0014] | [0.833] |
| DT | time | N8 | feed | temperature_k | N8 L0->N8 L1, N8 L1->N8 L2 | [8.7e-05, 4.32e-05] | [1.009] |
| DT | time | N8 | front | temperature_k | N8 L0->N8 L1, N8 L1->N8 L2 | [0.0819, 0.0406] | [1.011] |
| DT | time | N8 | positive film | temperature_k | N8 L0->N8 L1, N8 L1->N8 L2 | [0.148, 0.0761] | [0.963] |
| DT | time | N8 | absent film | temperature_k | N8 L0->N8 L1, N8 L1->N8 L2 | [0.00322, 0.00164] | [0.968] |
| DT | time | N16 | feed | hexane_rel_percent | N16 L0->N16 L1, N16 L1->N16 L2 | [0.000343, 0.000168] | [1.024] |
| DT | time | N16 | front | hexane_rel_percent | N16 L0->N16 L1, N16 L1->N16 L2 | [1.34, 0.759] | [0.816] |
| DT | time | N16 | positive film | hexane_rel_percent | N16 L0->N16 L1, N16 L1->N16 L2 | [2.04, 1.02] | [1.008] |
| DT | time | N16 | absent film | hexane_rel_percent | N16 L0->N16 L1, N16 L1->N16 L2 | [0.084, 0.0443] | [0.924] |
| DT | time | N16 | feed | moisture_pp | N16 L0->N16 L1, N16 L1->N16 L2 | [1.21e-05, 5.92e-06] | [1.033] |
| DT | time | N16 | front | moisture_pp | N16 L0->N16 L1, N16 L1->N16 L2 | [0.00883, 0.00533] | [0.727] |
| DT | time | N16 | positive film | moisture_pp | N16 L0->N16 L1, N16 L1->N16 L2 | [0.0129, 0.00682] | [0.922] |
| DT | time | N16 | absent film | moisture_pp | N16 L0->N16 L1, N16 L1->N16 L2 | [0.00268, 0.00134] | [1.006] |
| DT | time | N16 | feed | temperature_k | N16 L0->N16 L1, N16 L1->N16 L2 | [8.8e-05, 4.34e-05] | [1.019] |
| DT | time | N16 | front | temperature_k | N16 L0->N16 L1, N16 L1->N16 L2 | [0.0695, 0.041] | [0.761] |
| DT | time | N16 | positive film | temperature_k | N16 L0->N16 L1, N16 L1->N16 L2 | [0.159, 0.0815] | [0.967] |
| DT | time | N16 | absent film | temperature_k | N16 L0->N16 L1, N16 L1->N16 L2 | [0.00355, 0.00183] | [0.958] |
| DT | time | N32 | feed | hexane_rel_percent | N32 L0->N32 L1, N32 L1->N32 L2 | [0.000343, 0.000169] | [1.022] |
| DT | time | N32 | front | hexane_rel_percent | N32 L0->N32 L1, N32 L1->N32 L2 | [1.08, 0.649] | [0.737] |
| DT | time | N32 | positive film | hexane_rel_percent | N32 L0->N32 L1, N32 L1->N32 L2 | [2.1, 1.04] | [1.01] |
| DT | time | N32 | absent film | hexane_rel_percent | N32 L0->N32 L1, N32 L1->N32 L2 | [0.0972, 0.0543] | [0.841] |
| DT | time | N32 | feed | moisture_pp | N32 L0->N32 L1, N32 L1->N32 L2 | [1.21e-05, 5.91e-06] | [1.036] |
| DT | time | N32 | front | moisture_pp | N32 L0->N32 L1, N32 L1->N32 L2 | [0.00703, 0.00465] | [0.598] |
| DT | time | N32 | positive film | moisture_pp | N32 L0->N32 L1, N32 L1->N32 L2 | [0.0134, 0.00699] | [0.934] |
| DT | time | N32 | absent film | moisture_pp | N32 L0->N32 L1, N32 L1->N32 L2 | [0.00345, 0.00153] | [1.176] |
| DT | time | N32 | feed | temperature_k | N32 L0->N32 L1, N32 L1->N32 L2 | [8.92e-05, 4.4e-05] | [1.019] |
| DT | time | N32 | front | temperature_k | N32 L0->N32 L1, N32 L1->N32 L2 | [0.0555, 0.036] | [0.623] |
| DT | time | N32 | positive film | temperature_k | N32 L0->N32 L1, N32 L1->N32 L2 | [0.163, 0.0837] | [0.966] |
| DT | time | N32 | absent film | temperature_k | N32 L0->N32 L1, N32 L1->N32 L2 | [0.00412, 0.00212] | [0.96] |
| DT | time | N64 | feed | hexane_rel_percent | N64 L0->N64 L1, N64 L1->N64 L2 | [0.000342, 0.000169] | [1.018] |
| DT | time | N64 | front | hexane_rel_percent | N64 L0->N64 L1, N64 L1->N64 L2 | [0.795, 0.558] | [0.512] |
| DT | time | N64 | positive film | hexane_rel_percent | N64 L0->N64 L1, N64 L1->N64 L2 | [2.14, 1.07] | [1.006] |
| DT | time | N64 | absent film | hexane_rel_percent | N64 L0->N64 L1, N64 L1->N64 L2 | [0.113, 0.0625] | [0.85] |
| DT | time | N64 | feed | moisture_pp | N64 L0->N64 L1, N64 L1->N64 L2 | [1.23e-05, 5.92e-06] | [1.05] |
| DT | time | N64 | front | moisture_pp | N64 L0->N64 L1, N64 L1->N64 L2 | [0.00526, 0.00402] | [0.388] |
| DT | time | N64 | positive film | moisture_pp | N64 L0->N64 L1, N64 L1->N64 L2 | [0.0137, 0.0071] | [0.95] |
| DT | time | N64 | absent film | moisture_pp | N64 L0->N64 L1, N64 L1->N64 L2 | [0.0039, 0.00178] | [1.136] |
| DT | time | N64 | feed | temperature_k | N64 L0->N64 L1, N64 L1->N64 L2 | [8.85e-05, 4.42e-05] | [1.0] |
| DT | time | N64 | front | temperature_k | N64 L0->N64 L1, N64 L1->N64 L2 | [0.0415, 0.0309] | [0.426] |
| DT | time | N64 | positive film | temperature_k | N64 L0->N64 L1, N64 L1->N64 L2 | [0.166, 0.0851] | [0.965] |
| DT | time | N64 | absent film | temperature_k | N64 L0->N64 L1, N64 L1->N64 L2 | [0.00467, 0.00242] | [0.948] |
| Faner | mesh | L0 | feed | hexane_rel_percent | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [0.000337, 0.000455, 0.000698] | [-0.431, -0.617] |
| Faner | mesh | L0 | front | hexane_rel_percent | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [0.299, 0.0983, 0.0521] | [1.605, 0.916] |
| Faner | mesh | L0 | dry C | hexane_rel_percent | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [0.0111, 0.00806, 0.0074] | [0.463, 0.122] |
| Faner | mesh | L0 | feed | moisture_pp | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [9.98e-07, 1.55e-06, 2.45e-06] | [-0.64, -0.658] |
| Faner | mesh | L0 | front | moisture_pp | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [0.00025, 7.49e-05, 3.33e-05] | [1.738, 1.17] |
| Faner | mesh | L0 | dry C | moisture_pp | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [0.000907, 0.000205, 4.64e-05] | [2.143, 2.146] |
| Faner | mesh | L0 | feed | temperature_k | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [0.000102, 0.000139, 0.000216] | [-0.444, -0.637] |
| Faner | mesh | L0 | front | temperature_k | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [0.0141, 0.00426, 0.00156] | [1.721, 1.452] |
| Faner | mesh | L0 | dry C | temperature_k | N8 L0->N16 L0, N16 L0->N32 L0, N32 L0->N64 L0 | [0.00303, 0.00149, 0.00146] | [1.028, 0.024] |
| Faner | mesh | L1 | feed | hexane_rel_percent | N4 L1->N8 L1, N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [0.000274, 0.000159, 9.74e-05, 4.63e-05] | [0.781, 0.711, 1.075] |
| Faner | mesh | L1 | front | hexane_rel_percent | N4 L1->N8 L1, N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [0.802, 0.27, 0.0874, 0.0253] | [1.571, 1.627, 1.79] |
| Faner | mesh | L1 | dry C | hexane_rel_percent | N4 L1->N8 L1, N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [0.0217, 0.0102, 0.00603, 0.00272] | [1.08, 0.763, 1.149] |
| Faner | mesh | L1 | feed | moisture_pp | N4 L1->N8 L1, N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [9.09e-07, 5.07e-07, 3.01e-07, 1.41e-07] | [0.842, 0.752, 1.093] |
| Faner | mesh | L1 | front | moisture_pp | N4 L1->N8 L1, N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [0.000827, 0.000241, 6.75e-05, 2.17e-05] | [1.778, 1.835, 1.639] |
| Faner | mesh | L1 | dry C | moisture_pp | N4 L1->N8 L1, N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [0.00413, 0.000904, 0.000197, 4.23e-05] | [2.193, 2.195, 2.224] |
| Faner | mesh | L1 | feed | temperature_k | N4 L1->N8 L1, N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [8.41e-05, 4.83e-05, 2.84e-05, 1.3e-05] | [0.802, 0.767, 1.125] |
| Faner | mesh | L1 | front | temperature_k | N4 L1->N8 L1, N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [0.0402, 0.0134, 0.00372, 0.000893] | [1.583, 1.852, 2.058] |
| Faner | mesh | L1 | dry C | temperature_k | N4 L1->N8 L1, N8 L1->N16 L1, N16 L1->N32 L1, N32 L1->N64 L1 | [0.0084, 0.00286, 0.00139, 0.000561] | [1.552, 1.044, 1.31] |
| Faner | mesh | L2 | feed | hexane_rel_percent | N8 L2->N16 L2, N16 L2->N32 L2 | [7.79e-05, 4.6e-05] | [0.759] |
| Faner | mesh | L2 | front | hexane_rel_percent | N8 L2->N16 L2, N16 L2->N32 L2 | [0.265, 0.0742] | [1.836] |
| Faner | mesh | L2 | dry C | hexane_rel_percent | N8 L2->N16 L2, N16 L2->N32 L2 | [0.0111, 0.00422] | [1.391] |
| Faner | mesh | L2 | feed | moisture_pp | N8 L2->N16 L2, N16 L2->N32 L2 | [2.6e-07, 1.47e-07] | [0.82] |
| Faner | mesh | L2 | front | moisture_pp | N8 L2->N16 L2, N16 L2->N32 L2 | [0.000239, 6.26e-05] | [1.931] |
| Faner | mesh | L2 | dry C | moisture_pp | N8 L2->N16 L2, N16 L2->N32 L2 | [0.000901, 0.000195] | [2.209] |
| Faner | mesh | L2 | feed | temperature_k | N8 L2->N16 L2, N16 L2->N32 L2 | [2.36e-05, 1.34e-05] | [0.816] |
| Faner | mesh | L2 | front | temperature_k | N8 L2->N16 L2, N16 L2->N32 L2 | [0.0133, 0.00347] | [1.935] |
| Faner | mesh | L2 | dry C | temperature_k | N8 L2->N16 L2, N16 L2->N32 L2 | [0.00306, 0.00101] | [1.596] |
| Faner | time | N8 | feed | hexane_rel_percent | N8 L0->N8 L1, N8 L1->N8 L2 | [0.00041, 0.00012] | [1.768] |
| Faner | time | N8 | front | hexane_rel_percent | N8 L0->N8 L1, N8 L1->N8 L2 | [0.0905, 0.0431] | [1.069] |
| Faner | time | N8 | dry C | hexane_rel_percent | N8 L0->N8 L1, N8 L1->N8 L2 | [0.242, 0.121] | [1.004] |
| Faner | time | N8 | feed | moisture_pp | N8 L0->N8 L1, N8 L1->N8 L2 | [1.55e-06, 4.51e-07] | [1.779] |
| Faner | time | N8 | front | moisture_pp | N8 L0->N8 L1, N8 L1->N8 L2 | [6.08e-05, 3.02e-05] | [1.009] |
| Faner | time | N8 | dry C | moisture_pp | N8 L0->N8 L1, N8 L1->N8 L2 | [0.000457, 0.000229] | [0.995] |
| Faner | time | N8 | feed | temperature_k | N8 L0->N8 L1, N8 L1->N8 L2 | [0.000111, 3.32e-05] | [1.744] |
| Faner | time | N8 | front | temperature_k | N8 L0->N8 L1, N8 L1->N8 L2 | [0.00243, 0.0012] | [1.024] |
| Faner | time | N8 | dry C | temperature_k | N8 L0->N8 L1, N8 L1->N8 L2 | [0.0555, 0.0279] | [0.994] |
| Faner | time | N16 | feed | hexane_rel_percent | N16 L0->N16 L1, N16 L1->N16 L2 | [0.000454, 0.000152] | [1.583] |
| Faner | time | N16 | front | hexane_rel_percent | N16 L0->N16 L1, N16 L1->N16 L2 | [0.062, 0.0381] | [0.702] |
| Faner | time | N16 | dry C | hexane_rel_percent | N16 L0->N16 L1, N16 L1->N16 L2 | [0.241, 0.121] | [0.987] |
| Faner | time | N16 | feed | moisture_pp | N16 L0->N16 L1, N16 L1->N16 L2 | [1.7e-06, 5.61e-07] | [1.6] |
| Faner | time | N16 | front | moisture_pp | N16 L0->N16 L1, N16 L1->N16 L2 | [4.9e-05, 2.7e-05] | [0.859] |
| Faner | time | N16 | dry C | moisture_pp | N16 L0->N16 L1, N16 L1->N16 L2 | [0.000457, 0.000231] | [0.986] |
| Faner | time | N16 | feed | temperature_k | N16 L0->N16 L1, N16 L1->N16 L2 | [0.000125, 4.28e-05] | [1.546] |
| Faner | time | N16 | front | temperature_k | N16 L0->N16 L1, N16 L1->N16 L2 | [0.00181, 0.00101] | [0.845] |
| Faner | time | N16 | dry C | temperature_k | N16 L0->N16 L1, N16 L1->N16 L2 | [0.0552, 0.028] | [0.979] |
| Faner | time | N32 | feed | hexane_rel_percent | N32 L0->N32 L1, N32 L1->N32 L2 | [0.000131, 0.000157] | [-0.257] |
| Faner | time | N32 | front | hexane_rel_percent | N32 L0->N32 L1, N32 L1->N32 L2 | [0.0509, 0.025] | [1.026] |
| Faner | time | N32 | dry C | hexane_rel_percent | N32 L0->N32 L1, N32 L1->N32 L2 | [0.24, 0.119] | [1.008] |
| Faner | time | N32 | feed | moisture_pp | N32 L0->N32 L1, N32 L1->N32 L2 | [5.66e-07, 5.79e-07] | [-0.03] |
| Faner | time | N32 | front | moisture_pp | N32 L0->N32 L1, N32 L1->N32 L2 | [3.87e-05, 2.13e-05] | [0.863] |
| Faner | time | N32 | dry C | moisture_pp | N32 L0->N32 L1, N32 L1->N32 L2 | [0.000456, 0.000229] | [0.996] |
| Faner | time | N32 | feed | temperature_k | N32 L0->N32 L1, N32 L1->N32 L2 | [2.55e-05, 4.45e-05] | [-0.803] |
| Faner | time | N32 | front | temperature_k | N32 L0->N32 L1, N32 L1->N32 L2 | [0.00124, 0.000753] | [0.717] |
| Faner | time | N32 | dry C | temperature_k | N32 L0->N32 L1, N32 L1->N32 L2 | [0.055, 0.0276] | [0.996] |

## Interpretation (written against the data of this run; re-read when cases are added)

(interpretation pending)
