"""Freeze runtime 151: runtime-144 bytes plus the gate-normalized line-search merit.

Lead decision (Class A) under the hygiene principle of
GT_PS2_OWNER_RULING_PAPER1_NUMERICAL_GATE_HYGIENE_2026-10-17, recorded in
docs/GT_PS2_PAPER1_LINE_SEARCH_MERIT_BUILD_2026-10-18.md (evidence 149 the refusal, 150 the
build's measurements, tests and mutations): when the domain-aware Newton carries a per-row
acceptance clause (the dry advance), its line search judges a step by the max-norm of the
residual divided row by row by the clause's own gates at the current iterate, from the
Jacobian the Newton already holds (no residual call added); without a clause (births, face,
projection, extinction) the former unweighted 2-norm path is kept bit for bit. Harness only:
no native source byte changes from runtime 144. No gate, target, budget, tolerance, law or
declared value moves.

The runtime-144 record follows, unchanged in substance:

Freeze runtime 144: runtime-131 bytes plus the three ruled solver-gate changes.

Owner ruling GT_PS2_OWNER_RULING_PAPER1_GATE_UNITS_2026-10-17 (evidence 143): the dry
advance searches to its gate; its cell energy rows pass at max(1e-10, 2 x the row's
representability floor), stamped per row; the birth condition certificate is taken on
the column-2-norm-scaled matrix the search solves, against its own cap 1e8. Harness only:
no native source byte changes from runtime 131.

Owner ruling GT_PS2_OWNER_RULING_PAPER1_FILM_IMBIBITION_BRIDGE_2026-10-17. The one declared
native delta is src/dtdc_simulator/core2/through_bed_sorbed_water_law.py: the shared law
(bridged_water_activity / bridged_water_retained) with SorbedWaterArm.activity delegating to
it, bit-identical for the tower (tests/test_particle_imbibition_bridge.py). Every other
native byte must equal runtime 110.

No git command is run. The runtime-75 tree (a shared clone of the base commit
with its owned overlay) is copied verbatim, results excluded, then the complete
development Python source set is copied over it and hashed. Only owned harness
paths may differ from runtime 75; no native source byte may differ. Nothing is
launched here.
"""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
DEV = ROOT / "scratchpad/solver_qualification_2026_10_16"
PRED = ROOT / "scratchpad/solver_qualification_run_144"
EXEC = ROOT / "scratchpad/solver_qualification_run_151"
TARGET = OUT / "execution_freeze_151.json"
if EXEC.exists() or TARGET.exists():
    raise ValueError("refusing to reuse an execution directory or manifest")
previous = json.loads((OUT / "execution_freeze_144.json").read_text())
DECLARED_NATIVE = set()
owned = set(json.loads((OUT / "owned_paths_v19.json").read_text()))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


for relative, digest in previous["source_sha256"].items():
    if sha(PRED / relative) != digest:
        raise ValueError("runtime 144 differs from its own freeze: " + relative)


def ignore(directory, names):
    skipped = {n for n in names if n == "__pycache__"}
    if Path(directory).resolve() == (PRED / "paper/analysis").resolve():
        skipped |= {n for n in names if n.startswith("results_")}
    return skipped


shutil.copytree(PRED, EXEC, ignore=ignore)
manifest = {
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "base_commit": previous["base_commit"],
    "development": str(DEV),
    "execution": str(EXEC),
    "predecessor_runtime": "execution_freeze_144.json",
    "copied_from_predecessor_tree": str(PRED),
    "git_metadata": "runtime-144 .git (copied from runtimes 131, 120, 110, 106, 102, 98, 94, 90 and 75) copied verbatim (shared clone at the base commit); "
    "no git command was run to build this runtime",
    "source_sha256": {},
}
for directory in ("src", "paper/analysis/harness", "scripts"):
    for source in sorted((DEV / directory).rglob("*.py")):
        relative = source.relative_to(DEV)
        target = EXEC / relative
        if not target.resolve().is_relative_to(EXEC.resolve()):
            raise ValueError("copy escaped isolated runtime")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        digest = sha(source)
        if sha(target) != digest:
            raise ValueError("source copy mismatch")
        manifest["source_sha256"][relative.as_posix()] = digest
stale = sorted(
    p.relative_to(EXEC).as_posix()
    for d in ("src", "paper/analysis/harness", "scripts")
    for p in (EXEC / d).rglob("*.py")
    if p.relative_to(EXEC).as_posix() not in manifest["source_sha256"]
)
if stale:
    raise ValueError("runtime carries Python files absent from development: " + str(stale))
changes = sorted(
    p for p, h in manifest["source_sha256"].items() if previous["source_sha256"].get(p) != h
)
if any(p not in owned for p in changes):
    raise ValueError("unexpected runtime delta: " + str(changes))
if any(p.startswith("src/") and p not in DECLARED_NATIVE for p in changes):
    raise ValueError("native source bytes must match the prior numerical runtime")
for group in ("input_sha256", "import_configuration_sha256"):
    for relative, digest in previous[group].items():
        if sha(EXEC / relative) != digest:
            raise ValueError("runtime input differs: " + relative)
if sha(EXEC / previous["owner_authority"]["path"]) != previous["owner_authority"]["sha256"]:
    raise ValueError("owner authority copy differs")
pin = EXEC / previous["import_source_pin"]["path"]
canonical = pin.read_bytes().replace(b"\r\n", b"\n").replace(b"\r", b"\n")
if hashlib.sha256(canonical).hexdigest() != previous["import_source_pin"]["canonical_lf_sha256"]:
    raise ValueError("import configuration source pin differs")
log = (OUT / "focused_tests_151.log").read_text()
manifest.update(
    changed_runtime_paths=changes,
    native_source_bytes_changed_from_predecessor=sorted(p for p in changes if p.startswith("src/")),
    native_change_since_runtime_110="src/dtdc_simulator/core2/through_bed_sorbed_water_law.py (declared in execution_freeze_120.json; unchanged since)",
    predecessor_ladder="runtime 144 (convergence_ladder_status_145.json): DT N64 L0 refused at 1253.46 s on the dry 1,400-call allowance (evidence 149: the unweighted 2-norm line search refused the full Newton step the per-row clause accepts), Faner N64 L2 refused at birth on the Ackermann band (not ruled), DT N64 L2 still running at this freeze; read on runtime 151 only",
    line_search_merit_decision={"record": "docs/GT_PS2_PAPER1_LINE_SEARCH_MERIT_BUILD_2026-10-18.md", "class": "A (lead decision under the hygiene principle of GT_PS2_OWNER_RULING_PAPER1_NUMERICAL_GATE_HYGIENE_2026-10-17)", "change": "particle_numerical_repairs.domain_aware_newton: with an acceptance clause, the sufficient-decrease test |v_trial| < (1 - 1e-4 alpha) |v_current| on v = r / g, g = acceptance.gates(x, jac) at the current iterate from the Newton's own Jacobian there (energy rows max(1e-10, 2 floor_i), every other row its fixed gate), the declared norm GATE_NORMALIZED_MERIT_NORM = max; the merit and every accepted step (damping, length, retreats, merit before and after) returned as line_search and stamped per advance in dry.history native_report.line_search with newton_residual_calls and newton_certificate_calls_outside_search_budget; without a clause the former code path bit for bit (tests against runtime 144's own Newton)", "added_residual_calls": 0, "declared_row": "case.json numerical_gate_ruling_settings.gate_units.declared_rows[3] dry_line_search_merit_in_gate_units", "evidence": "line_search_merit_150_*.json, line_search_march_150_*.json, line_search_noise_150_*.json, line_search_merit_mutations_150.json", "tests": "tests/test_particle_line_search_merit.py (17)"},
    gate_units_ruling={"record": "GT_PS2_OWNER_RULING_PAPER1_GATE_UNITS_2026-10-17", "packet": "docs/GT_PS2_PAPER1_GATE_UNITS_RULING_PACKET_2026-10-17.md", "point_1_dry_search_target": "experiment_core2_dt_dry.advance searches to its declared gate tolerance (config nonlinear_residual_tolerance, 1e-10 on the ladder); the former min(5e-11, tolerance) and its tighten-only override removed; a differing search_tolerance is a typed refusal (DrySearchTargetRefused), also at advance_dry_phases entry; the cell water/hexane rows stay weighted to the strict native component limit min(2e-11, tolerance)", "point_2_noise_aware_energy_rows": "each cell energy row passes at max(tolerance, 2 * floor_i), floor_i = sum_j |J_ij| ulp(x_j) from the domain-aware Newton dense forward-difference Jacobian at the returned iterate; the Newton returns an iterate passing every per-row gate (acceptance clause; the candidate certificate Jacobian outside max_nfev when returned, charged when refused); the native _accept_step energy scales multiplied by gate_i / tolerance (1 on unabsorbed rows); water, hexane and surface node rows keep 1e-10; stamped per row in dry.history native_report.noise_aware_energy_row_gate and case.json noise_aware_energy_gate_summary; declared multiple 2.0; the face-flux scaling not adopted", "point_3_birth_certificate": "np.linalg.cond of the column-2-norm-scaled physical joint birth Jacobian (particle_numerical_repairs.search_column_scale, the Newton least-squares matrix), DT and Faner alike, against experiment_core2_dt_birth.MAXIMUM_BIRTH_CONDITION_PROXY = 1e8 (beside controls.maximum_condition_proxy 1e12, untouched for the film node, the face solve and the extinction projection); the raw-column proxy and the native pullback condition reported in birth.json birth_condition_certificate, not gated; the birth ledger condition_proxy carries the gated value; the radius-normalized audit knob computes and stamps as before", "not_ruled": "the wet-core trace scope, the Ackermann birth band, the saturated loading grounding, the 0.02 K outlet-temperature time goal", "tests": "tests/test_particle_gate_units_ruling.py; no-op mutations gate_units_mutations_143.json", "smoke": "gate_units_smoke_143_*.json"},
    hexane_front_interface_scope="cut_transport._solve_interface_composition_with_audit runs on the native equilibrium: the zero-volume wet trace keeps the cap graph with the KKT dual log(a_w,dry/a_w,cap); gas side identical; no storage; declared reading of the ruling scope (the wet core is not among the ruled routes); tests/test_particle_imbibition_bridge.py::test_hexane_front_interface_traces_keep_the_native_cap_graph",
    declared_native_change={"path": "src/dtdc_simulator/core2/through_bed_sorbed_water_law.py", "authority": "GT_PS2_OWNER_RULING_PAPER1_FILM_IMBIBITION_BRIDGE_2026-10-17", "content": "the one shared implementation bridged_water_activity / bridged_water_retained; SorbedWaterArm.activity delegates to it; tower activities bit-identical (identity test on a (W, T) grid including above the cap)"},
    native_source_files=sum(p.startswith("src/") for p in manifest["source_sha256"]),
    input_sha256=previous["input_sha256"],
    import_configuration_sha256=previous["import_configuration_sha256"],
    owner_authority=previous["owner_authority"],
    import_source_pin=previous["import_source_pin"],
    conditioning_definition=previous["conditioning_definition"],
    conditioning_owner_approved_for_qualification_only=True,
    explicit_trial_native_dry_local_tolerance=1e-10,
    previous_local_tolerance=2e-11,
    policy_adopted_for_submission=False,
    conservative_original_feed_components=True,
    conservative_positive_film_elimination=True,
    declared_film_depletion_search_options={
        "--event-first-film-depletion": "predicted exact-zero event first (linear film "
        "extrapolation of the last two accepted advances, cells extrapolated likewise), "
        "eliminated positive-film search stopped at its first nonpositive film",
        "--eliminate-event-absent-components": "algebraic component elimination of the "
        "depletion-event (water closure fixes T_s, bounded 1e-8 s duration shift removes "
        "the representable remainder) and absent-film (affine Stefan inverse) active sets; "
        "explicit per-advance budget acceptance guard",
        "off": "former code path; keywords passed to the dry advance unchanged",
    },
    checkpoint_replace_retry="qualify_sliding_front_history.replace_with_retry: bounded back-off (12 retries, 16.95 s), every refused attempt logged in checkpoint_replace_retries, typed CheckpointReplaceRefused after exhaustion; used by the front and C-stage checkpoint writers; content and accepted sequence unchanged; tests/test_particle_checkpoint_replace_retry.py",
    imbibition_bridge_ruling={"record": "GT_PS2_OWNER_RULING_PAPER1_FILM_IMBIBITION_BRIDGE_2026-10-17", "default": "--imbibition-bridge ruled --saturated-loading 0.55 (declared parameter, sweep [0.25, 0.97])", "shape": "Horrobin finite intercept W_sat - W = c1 (1 - a_w), continuous at (W_cap, 0.799); a_w = 1 at and above W_sat", "particle_routes": "sp.water_activity, sp.water_retained, dry_limit_moisture_branch activity and derivative, coupled_pore equilibrium above the cap (surface node under the film through the same equilibrium; film-free surface follows the gas activity at T_s)", "rebinding": "paper/analysis/harness/particle_imbibition_bridge.py install/uninstall; no particle source byte carries a second copy", "replay_options": {"--imbibition-bridge former-bridge": "C8 tier-1 linear bridge x_bf 0.25", "--imbibition-bridge plain-cap": "the former capacity active set"}, "tests": "tests/test_particle_imbibition_bridge.py", "declared_rows": "case.json numerical_gate_ruling_settings.imbibition_bridge.declared_rows"},
    declared_depletion_prediction={"--curvature-corrected-depletion-prediction": "seed the event-first depletion with the parabola through the last three accepted films (seeding only); evidence 121 (the line put a 2.531 s event inside a 2.5 s interval and the event solve spent 1292 of 1400 assemblies outside it) and 125/126 (the 32-cell bridged march reaches depletion); tests/test_particle_film_depletion_event_first.py"},
    owner_ruling={"record": "GT_PS2_OWNER_RULING_PAPER1_NUMERICAL_GATE_HYGIENE_2026-10-17", "defaults": {"dry_local_residual_tolerance": "1e-10 (2e-11 by --dry-local-tolerance)", "proof_allowance": "3,000,000 points and 1200 per path, no wall-clock clause (former clause by --proof-wall-clock-clause)", "certificate_jacobian": "outside the unchanged residual-call search budget (former counting by --certificate-within-search-budget)"}, "measurement": "probe_DT64_certificate_outside_107_default.json"},
    declared_refusal_options={"--front-search-at-acceptance-gate": "B: front driver searches to controls.nonlinear_residual_tolerance instead of 1e-11; native checks unchanged; probe_Faner4_gate_search_104.json", "--conservative-core-endpoint": "C: core-extinction projection with the eliminated positive-film endpoint surface; native and combined ledgers unchanged; probe_DT2_conservative_endpoint_105_on.json", "A": "refuted (probe_DT64_best_point_103.json); not built"},
    declared_proof_option={"--memoize-proof-points": "within one proof allowance, bit-identical native path-coordinate evaluations (T, y, P, pore exact bits) are reused; every requested point, hits included, still counts against the unchanged 3,000,000-point/1200-per-path/120 s clauses; tests/test_particle_proof_memo.py; probe_proof_memo_100_*"},
    declared_birth_search_option={"--grouped-birth-search": "Faner joint birth: grouped-colour Newton search directions from the native birth sparsity plus a dense surface superset; dense first and final Jacobians, budget 2400, tolerances, cap 1e12 and laws unchanged; evidence probes 85-87 and tests/test_particle_faner_grouped_birth_search.py"},
    inert_development_delta=(
        "paper/analysis/harness/particle_numerical_repairs.py carries the development "
        "tree's optional grouped search Jacobian (search_jacobian_sparsity, default None); "
        "the dry DT path never passes it; the Faner birth passes it only under --grouped-birth-search"
    ),
    birth_radius_chart_owner_approval="PENDING; not enabled",
    film_depletion_refuting_measurement=[
        "eliminated_film_depletion_N8L0_88.json",
        "eliminated_film_depletion_N16L1_88.json",
        "eliminated_film_depletion_DT32_84_88.json",
    ],
    focused_test_log="focused_tests_144.log",
    focused_tests_passed=int(log.strip().splitlines()[-1].split()[0]),
    qualification_complete=False,
    convergence_established=False,
    physically_qualifying=False,
    purpose="the whole convergence ladder (DT and Faner 8/16/32/64 at L0/1/2, DT2 and Faner4 at L1) and the W_sat sensitivity rows under the ruled imbibition bridge, "
    "the ruled gate units and the gate-normalized line-search merit; nothing adopted before this ladder is read",
)
with TARGET.open("x") as stream:
    json.dump(manifest, stream, indent=2)
print(
    json.dumps(
        {
            "runtime": str(EXEC),
            "files": len(manifest["source_sha256"]),
            "changed": changes,
            "focused_tests_passed": manifest["focused_tests_passed"],
        }
    )
)
