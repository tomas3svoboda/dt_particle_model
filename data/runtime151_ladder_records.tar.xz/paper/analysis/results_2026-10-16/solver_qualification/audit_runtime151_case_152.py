"""Independent original-feed audit of a runtime-151 case under the case's own declared imbibition law.

usage: audit_runtime151_case_152.py STUDY CASE_FOLDER OUT_JSON
The ruled bridge (GT_PS2_OWNER_RULING_PAPER1_FILM_IMBIBITION_BRIDGE_2026-10-17) is part of
the model the case ran with; the auditor's native EOS reconstruction must use the same law,
so it is installed with the mode and W_sat recorded in the case's own case.json before the
unchanged auditor runs (DT: runtime-151 audit_particle_qualification_case.py; Faner:
audit_fresh_Faner_case_51.py on runtime 151).
"""

import json
from pathlib import Path
import runpy
import sys

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
RUNTIME = ROOT / "scratchpad/solver_qualification_run_151"
study, case, target = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3])
sys.path[:0] = [str(RUNTIME / "src"), str(RUNTIME / "paper/analysis/harness")]
sys.dont_write_bytecode = True
import particle_imbibition_bridge as imbibition  # noqa: E402

settings = json.loads((case / "case.json").read_text())["numerical_gate_ruling_settings"]["imbibition_bridge"]
imbibition.install(settings["mode"], settings["saturated_loading_kg_kg_dry"] or imbibition.W_SAT_NOMINAL)
if study == "DT":
    sys.argv = [
        "audit_particle_qualification_case.py",
        "--case", str(case),
        "--bath", str(RUNTIME / "paper/analysis/inputs/qualification_DT_bath.json"),
        "--out", str(target),
    ]
    runpy.run_path(str(RUNTIME / "paper/analysis/harness/audit_particle_qualification_case.py"), run_name="__main__")
else:
    sys.argv = ["audit_fresh_Faner_case_51.py", "--runtime", str(RUNTIME), "--case", str(case), "--out", str(target)]
    runpy.run_path(str(OUT / "audit_fresh_Faner_case_51.py"), run_name="__main__")
