"""Evidence 157: export the adopted runtime-151 ladder histories for the Paper-1 figures and numbers.

Read-only on the runtime-151 case trees (ruled film-imbibition bridge, w_sat 0.55, gate-units
ruling, line-search merit). No march, no model import. Writes, beside this script:
  ladder151_faner_N64_L1_history_157.csv   (columns of the former Faner figure history)
  ladder151_DT_N64_L1_history_157.csv      (columns of the former DT figure history)
  ladder151_paper_numbers_157.json         (every printed number, per rung, with sha256 of inputs)
The adopted resolution is 64 cells at the middle time level (owner order 2026-10-18); the other
rungs are carried for the refinement tables. Flux decompositions follow the SI reconstruction
(paper/analysis/results_2026-10-15/dt_factor100/collect_study.py, flux_contributions): upstream
hexane fraction = outer cell for outward total gas flux, surface for inward; net hexane flux =
boundary_hexane_out_mol / (4 pi R^2 dt), on every accepted regime-C (dry-history) advance.
physically_qualifying: false.
"""

import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
L151 = ROOT / "scratchpad/solver_qualification_run_151/paper/analysis/results_2026-10-17/ladder_151"
DT_EXIT = 1766.5355008060146
HOLDER_CLOCK = 235.058
MEAS_FALL = 25.350441949123166
RADIUS = {"DT": 0.0015, "Faner": 0.000885}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_case(study, cells):
    folder = L151 / f"{study}_N{cells}_L1"
    case = json.loads((folder / "case.json").read_text())
    assert case["complete_history"] and case["sources_unchanged_during_run"]
    assert case["numerical_gate_ruling_settings"]["imbibition_bridge"]["mode"] == "ruled"
    assert case["time_level"] == 1 and case["base_cells"] == cells and not case["physically_qualifying"]
    src = folder / ("birth.json" if study == "Faner" else "feed.json")
    d = json.loads(src.read_text())
    feed = d["feed_rows"] if study == "Faner" else d["rows"]
    rows, betas, birth_betas = [], [], []
    for r in feed:
        rows.append(
            {
                "time_s": r["t_s"],
                "hexane_kg_kg_dry": r["hexane_kg_kg_dry"],
                "particle_water_kg_kg_dry": r["retained_water_kg_kg_dry"],
                "external_water_kg_kg_dry": r["external_water_kg_kg_dry"],
                "temperature_k": r["temperature_k"],
                "outer_cell_retained_water_kg_kg_dry": None,
                "front_z": 1.0,
                "stage": "A",
            }
        )
        if r.get("beta") is not None:
            betas.append(abs(r["beta"]))
    feed_end = rows[-1]["time_s"]
    core_end = depletion = None
    flux = []
    area = 4 * math.pi * RADIUS[study] ** 2
    for name, stage in (("front.history.jsonl", "B"), ("dry.history.jsonl", "C")):
        for line in (folder / name).read_text().splitlines():
            r = json.loads(line)
            if r["kind"] == "initial" and name == "front.history.jsonl":
                s0 = r.get("surface") or {}
                if s0.get("beta") is not None:
                    birth_betas.append(abs(s0["beta"]))
            if r["kind"] in ("refusal", "initial") or r["time_s"] <= rows[-1]["time_s"]:
                continue
            surface = r.get("surface") or {}
            if surface.get("beta") is not None:
                betas.append(abs(surface["beta"]))
            cells_w = r.get("retained_water_cells_kg_kg_dry")
            rows.append(
                {
                    "time_s": r["time_s"],
                    "hexane_kg_kg_dry": r["hexane_kg_kg_dry"],
                    "particle_water_kg_kg_dry": r["particle_water_kg_kg_dry"],
                    "external_water_kg_kg_dry": r["external_water_kg_kg_dry"],
                    "temperature_k": r["temperature_k"],
                    "outer_cell_retained_water_kg_kg_dry": cells_w[-1] if cells_w else None,
                    "front_z": r["front_z"] if r.get("front_z") is not None else (0.0 if stage == "C" else None),
                    "stage": stage,
                }
            )
            if r.get("front_z") is not None:
                core_end = r["time_s"]
            if r["kind"] == "depletion" and depletion is None:
                depletion = r["time_s"]
            if stage == "C":
                ledger = r["native_report"]["ledger"]
                total = ledger["stefan_recovery"]["total_stefan_fluxes_mol_m2_s"][-1]
                upstream = r["y_hexane_cells"][-1] if total >= 0 else surface["surface_y_hexane"]
                net = ledger["boundary_hexane_out_mol"] / (area * ledger["dt_s"])
                motion = upstream * total
                flux.append(
                    {
                        "time_s": r["time_s"],
                        "kind": r["kind"],
                        "total_gas_flux_mol_m2_s": total,
                        "net_hexane_flux_mol_m2_s": net,
                        "motion_percent": 100 * motion / net,
                        "diffusion_percent": 100 * (net - motion) / net,
                    }
                )
    t = [r["time_s"] for r in rows]
    assert all(b > a for a, b in zip(t, t[1:]))
    audit_path = OUT / f"ladder151_{study}_N{cells}_L1_original_feed_audit_152.json"
    audit = json.loads(audit_path.read_text())
    assert audit["passed"] and audit["complete_history"]
    return {
        "folder": folder,
        "rows": rows,
        "feed_end_s": feed_end,
        "core_end_s": core_end,
        "film_depletion_s": depletion,
        "flux": flux,
        "max_abs_beta": max(betas + birth_betas),
        "max_abs_beta_after_birth": max(betas),
        "birth_abs_beta": max(birth_betas) if birth_betas else None,
        "audit": audit,
        "audit_path": audit_path,
        "inputs": [folder / "case.json", src, folder / "front.history.jsonl", folder / "dry.history.jsonl", audit_path],
    }


def series(c, key):
    return np.array([np.nan if r[key] is None else r[key] for r in c["rows"]], dtype=float)


def at(c, key, clock):
    return float(np.interp(clock, series(c, "time_s"), series(c, key)))


def crossing(c, level):
    t, x = series(c, "time_s"), series(c, "hexane_kg_kg_dry")
    for i in range(len(t) - 1):
        if x[i] >= level >= x[i + 1]:
            return float(t[i] + (t[i + 1] - t[i]) * (x[i] - level) / (x[i] - x[i + 1]))
    raise ValueError("crossing missing")


def faner_numbers(c):
    c20, c10 = crossing(c, 0.20), crossing(c, 0.10)
    f = c["flux"]
    diff = [r["diffusion_percent"] for r in f]
    return {
        "FanerDryTime": c["core_end_s"],
        "FanerCrossTwenty": c20,
        "FanerFallingInterval": c10 - c20,
        "FanerExitHexane": at(c, "hexane_kg_kg_dry", 240.0),
        "FanerExitWater": at(c, "particle_water_kg_kg_dry", 240.0),
        "FanerExitTemperature": at(c, "temperature_k", 240.0) - 273.15,
        "FanerFreeEnd": c["feed_end_s"],
        "FanerFallingShortfall": 100 * (1 - (c10 - c20) / MEAS_FALL),
        "FanerMaxBeta": c["max_abs_beta"],
        "max_abs_beta_after_birth": c["max_abs_beta_after_birth"],
        "birth_abs_beta": c["birth_abs_beta"],
        "FanerLastHolderClockTemperature": at(c, "temperature_k", HOLDER_CLOCK) - 273.15,
        "regime_C_advances": len(f),
        "regime_C_first": f[0],
        "regime_C_last": f[-1],
        "advances_with_diffusion_opposing": sum(d < 0 for d in diff),
        "diffusion_percent_range_opposing": [min(diff), max(diff)],
        "audit_max_W_H_U": c["audit"]["maximum_independent_normalized_W_H_U"],
    }


def dt_numbers(c):
    W, H = at(c, "particle_water_kg_kg_dry", DT_EXIT), at(c, "hexane_kg_kg_dry", DT_EXIT)
    f = c["flux"]
    signs = [r["total_gas_flux_mol_m2_s"] >= 0 for r in f]
    changes = [
        {"time_s": f[i]["time_s"], "now_outward": signs[i]} for i in range(1, len(f)) if signs[i] != signs[i - 1]
    ]
    last_out = max((i for i, s in enumerate(signs) if s), default=-1)
    ext = c["core_end_s"]
    return {
        "DTFiniteHexaneDry": 1e6 * H,
        "DTFiniteHexaneWet": 1e6 * H / (1 + W + H),
        "DTFiniteMoisture": 100 * W / (1 + W + H),
        "DTFiniteTemperature": at(c, "temperature_k", DT_EXIT) - 273.15,
        "exit_particle_water_kg_kg_dry": W,
        "exit_external_water_kg_kg_dry": at(c, "external_water_kg_kg_dry", DT_EXIT),
        "dry_shell_s": c["feed_end_s"],
        "core_extinction_s": ext,
        "film_depletion_s": c["film_depletion_s"],
        "particle_water_at_extinction": at(c, "particle_water_kg_kg_dry", ext),
        "external_water_at_extinction": at(c, "external_water_kg_kg_dry", ext),
        "external_free_hexane_depletion_s": None,
        "regime_C_advances": len(f),
        "regime_C_first": f[0],
        "regime_C_last": f[-1],
        "total_gas_flux_sign_changes": changes,
        "inward_advances_after_last_outward": len(f) - 1 - last_out,
        "first_inward_after_last_outward_s": f[last_out + 1]["time_s"] if last_out + 1 < len(f) else None,
        "audit_max_W_H_U": c["audit"]["maximum_independent_normalized_W_H_U"],
    }


def write_csv(path, rows, columns):
    with path.open("w", newline="", encoding="utf-8") as s:
        w = csv.DictWriter(s, fieldnames=columns, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: ("" if r.get(k) is None else r[k]) for k in columns})


def main():
    out = {"evidence": 157, "physically_qualifying": False, "adopted": "N64 L1 (middle time level), runtime 151",
           "faner": {}, "dt": {}, "input_sha256": {}}
    cases = {}
    for n in (4, 8, 16, 32, 64):
        c = read_case("Faner", n)
        cases[("Faner", n)] = c
        out["faner"][f"N{n}"] = faner_numbers(c)
    for n in (2, 8, 16, 32, 64):
        c = read_case("DT", n)
        cases[("DT", n)] = c
        out["dt"][f"N{n}"] = dt_numbers(c)
    for c in cases.values():
        for p in c["inputs"]:
            out["input_sha256"][p.relative_to(ROOT).as_posix()] = sha(p)
    # external free hexane depletion (DT): last feed row with positive attached hexane
    for n in (2, 8, 16, 32, 64):
        feed = json.loads((L151 / f"DT_N{n}_L1/feed.json").read_text())["rows"]
        pos = [r["t_s"] for r in feed if r["attached_hexane_kg_kg_dry"] > 0]
        out["dt"][f"N{n}"]["external_free_hexane_depletion_s"] = (
            next((r["t_s"] for r in feed if r["t_s"] > pos[-1]), None) if pos else None
        )
        out["dt"][f"N{n}"]["attached_hexane_at_pd_exit"] = float(
            np.interp(490.20224190324825, [r["t_s"] for r in feed], [r["attached_hexane_kg_kg_dry"] for r in feed])
        )
    fan = cases[("Faner", 64)]
    write_csv(
        OUT / "ladder151_faner_N64_L1_history_157.csv",
        [
            {
                "t_s": r["time_s"],
                "hexane_kg_kg_dry": r["hexane_kg_kg_dry"],
                "water_kg_kg_dry": r["particle_water_kg_kg_dry"],
                "mean_temperature_k": r["temperature_k"],
                "surface_water_kg_kg_dry": r["outer_cell_retained_water_kg_kg_dry"],
                "front_z": r["front_z"],
                "stage": {"A": "attached", "B": "radial", "C": "stationary dry"}[r["stage"]],
            }
            for r in fan["rows"]
        ],
        ["t_s", "hexane_kg_kg_dry", "water_kg_kg_dry", "mean_temperature_k", "surface_water_kg_kg_dry", "front_z", "stage"],
    )
    dt = cases[("DT", 64)]
    write_csv(
        OUT / "ladder151_DT_N64_L1_history_157.csv",
        dt["rows"],
        ["time_s", "temperature_k", "particle_water_kg_kg_dry", "hexane_kg_kg_dry", "external_water_kg_kg_dry", "front_z", "stage"],
    )
    out["flux_N64"] = {"Faner": fan["flux"], "DT": dt["flux"]}
    out["outputs"] = {
        "faner_csv": "ladder151_faner_N64_L1_history_157.csv",
        "dt_csv": "ladder151_DT_N64_L1_history_157.csv",
    }
    out["script_sha256"] = sha(__file__)
    (OUT / "ladder151_paper_numbers_157.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    brief = {k: {n: {kk: vv for kk, vv in v.items() if not isinstance(vv, (dict, list))} for n, v in out[k].items()} for k in ("faner", "dt")}
    print(json.dumps(brief, indent=1))
    for s in ("faner", "dt"):
        for n, v in out[s].items():
            print(s, n, "first", v["regime_C_first"], "last", v["regime_C_last"])
    print("DT N64 sign changes", out["dt"]["N64"]["total_gas_flux_sign_changes"])


if __name__ == "__main__":
    main()
