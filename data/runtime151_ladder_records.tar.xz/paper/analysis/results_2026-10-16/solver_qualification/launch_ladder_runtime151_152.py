"""Staggered launcher of the runtime-151 convergence ladder (ruled imbibition bridge, ruled gate units and the
gate-normalized line-search merit of docs/GT_PS2_PAPER1_LINE_SEARCH_MERIT_BUILD_2026-10-18.md), evidence 152.
Derived from launch_ladder_runtime144_145.py by renumbering only: same queue, worker budget and stagger.

Long-running and detached. Launches each queued case as its own one-thread process once
the measured working set of all python.exe processes on this host plus the declared
weight of the next case stays within BUDGET_GB (and allows LAUNCH_SETTLE_S between
launches so the previous one shows its working set). Never touches a running process.
The manifest convergence_ladder_launched_152.json is rewritten after every launch.

Faner carries no exterior film: the film-depletion pair is DT only (the absent-film
elimination refuses Faner's first dry advance under either law, evidence 131).

Queue order: level-1 mesh rungs, then level 0, then level 2, then the former production
resolutions and the W_sat sensitivity rows (DT 16 cells, level 1).
"""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
EXEC = ROOT / "scratchpad/solver_qualification_run_151"
PYTHON = str(ROOT / ".venv/Scripts/python.exe")
MANIFEST = OUT / "convergence_ladder_launched_152.json"
BUDGET_GB = 38.0
LAUNCH_SETTLE_S = 240
WEIGHT_GB = {2: 1.5, 4: 2.0, 8: 2.5, 16: 4.0, 32: 6.5, 64: 13.0}
FLAGS = {
    "B": ["--front-search-at-acceptance-gate"],
    "C": ["--conservative-core-endpoint"],
    "G": ["--grouped-birth-search"],
    "M": ["--memoize-proof-points"],
    "F": ["--event-first-film-depletion", "--eliminate-event-absent-components",
          "--curvature-corrected-depletion-prediction"],
}


def queue():
    jobs = []
    for level in (1, 0, 2):
        for cells in (8, 16, 32, 64):
            for study in ("DT", "Faner"):
                opts = (["F", "M"] if study == "DT" else ["M"] + (["G"] if cells >= 64 else []))
                jobs.append((study, cells, level, opts, None))
    jobs.append(("DT", 2, 1, ["F", "M", "C"], None))
    jobs.append(("Faner", 4, 1, ["M", "B"], None))
    for w_sat in (0.25, 0.32, 0.75, 0.97):
        jobs.append(("DT", 16, 1, ["F", "M"], w_sat))
    return jobs


def working_set_gb():
    out = subprocess.run(
        [
            "powershell", "-NoProfile", "-Command",
            "(Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | Measure-Object WorkingSetSize -Sum).Sum",
        ],
        capture_output=True, text=True, check=False,
    )
    try:
        return float(out.stdout.strip()) / 2**30
    except ValueError:
        return BUDGET_GB


def main():
    freeze = json.loads((OUT / "execution_freeze_151.json").read_text())
    if any(hashlib.sha256((EXEC / p).read_bytes()).hexdigest() != h for p, h in freeze["source_sha256"].items()):
        raise SystemExit("runtime 151 differs from its freeze")
    env = {
        **os.environ,
        "PYTHONHASHSEED": "1",
        "PYTHONPATH": "src;paper/analysis/harness",
        "PYTHONDONTWRITEBYTECODE": "1",
        **{k: "1" for k in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS")},
    }
    bath = EXEC / "paper/analysis/inputs/qualification_DT_bath.json"
    record = {"runtime_freeze": "execution_freeze_151.json", "budget_gb": BUDGET_GB, "jobs": [],
              "ruling": ["GT_PS2_OWNER_RULING_PAPER1_FILM_IMBIBITION_BRIDGE_2026-10-17", "GT_PS2_OWNER_RULING_PAPER1_GATE_UNITS_2026-10-17",
                         "lead decision (Class A): docs/GT_PS2_PAPER1_LINE_SEARCH_MERIT_BUILD_2026-10-18.md"], "physically_qualifying": False}
    pending = queue()
    while pending:
        study, cells, level, opts, w_sat = pending[0]
        weight = WEIGHT_GB[cells]
        used = working_set_gb()
        if used + weight > BUDGET_GB:
            time.sleep(120)
            continue
        if w_sat is None:
            output = EXEC / f"paper/analysis/results_2026-10-17/ladder_151/{study}_N{cells}_L{level}"
            name = f"ladder151_{study}_N{cells}_L{level}_152"
        else:
            output = EXEC / f"paper/analysis/results_2026-10-17/ladder_151_sweep/{study}_N{cells}_L{level}_wsat{w_sat}"
            name = f"ladder151_{study}_N{cells}_L{level}_wsat{w_sat}_152"
        if output.exists():
            pending.pop(0)
            continue
        output.parent.mkdir(parents=True, exist_ok=True)
        argv = [PYTHON, str(EXEC / "paper/analysis/harness/run_particle_qualification_case.py"),
                "--study", study, "--cells", str(cells), "--time-level", str(level),
                "--per-area-qualification", "--dry-local-tolerance", "1e-10", "--conservative-components",
                "--out", str(output)]
        for key in opts:
            argv += FLAGS[key]
        if w_sat is not None:
            argv += ["--saturated-loading", repr(w_sat)]
        if study == "DT":
            argv += ["--bath", str(bath)]
        with (OUT / (name + ".log")).open("x") as log:
            process = subprocess.Popen(argv, cwd=EXEC, env=env, stdout=log, stderr=subprocess.STDOUT,
                                       creationflags=subprocess.CREATE_NO_WINDOW)
        record["jobs"].append({"name": name, "pid": process.pid, "study": study, "cells": cells, "level": level,
                               "options": opts, "saturated_loading": w_sat if w_sat is not None else 0.55,
                               "argv": argv, "output": str(output),
                               "launched_utc": datetime.now(timezone.utc).isoformat(),
                               "working_set_gb_before": round(used, 2)})
        temporary = MANIFEST.with_suffix(".tmp")
        temporary.write_text(json.dumps(record, indent=2))
        temporary.replace(MANIFEST)
        pending.pop(0)
        time.sleep(LAUNCH_SETTLE_S)
    record["all_launched_utc"] = datetime.now(timezone.utc).isoformat()
    temporary = MANIFEST.with_suffix(".tmp")
    temporary.write_text(json.dumps(record, indent=2))
    temporary.replace(MANIFEST)


if __name__ == "__main__":
    main()
