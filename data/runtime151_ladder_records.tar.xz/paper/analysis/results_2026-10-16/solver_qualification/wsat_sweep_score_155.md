# Evidence 155: saturated-loading sweep, DT N16 L1, runtime 151, against nominal 0.55

| w_sat | status | film-depletion time (s) | core endpoint time (s) | outlet hexane (ppm wet) | outlet moisture (% wet) | outlet temperature (K) | vs 0.55 outlet hexane (% rel) | vs 0.55 outlet moisture (pp) | vs 0.55 outlet temperature (K) | vs 0.55 whole-history hexane max rel (%) | vs 0.55 whole-history moisture max (pp) | vs 0.55 whole-history temperature max (K) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0.25 | COMPLETE_CANDIDATE_PENDING_CONVERGENCE_AND_INDEPENDENT_WHOLE_HISTORY_AUDIT | 564.913 | 502.466 | 83.9728 | 18.4279 | 378.048 | 49.3312 | 0.393224 | 0.0962353 | 49.3312 | 0.441214 | 0.605152 |
| 0.32 | COMPLETE_CANDIDATE_PENDING_CONVERGENCE_AND_INDEPENDENT_WHOLE_HISTORY_AUDIT | 558.525 | 502.466 | 98.6765 | 18.4729 | 377.965 | 27.0795 | 0.348254 | 0.0135441 | 27.0795 | 0.351285 | 0.303971 |
| 0.55 | COMPLETE_CANDIDATE_PENDING_CONVERGENCE_AND_INDEPENDENT_WHOLE_HISTORY_AUDIT | 553.138 | 502.466 | 125.398 | 18.8211 | 377.951 |  |  |  |  |  |  |
| 0.75 | COMPLETE_CANDIDATE_PENDING_CONVERGENCE_AND_INDEPENDENT_WHOLE_HISTORY_AUDIT | 551.536 | 502.466 | 133.66 | 19.0309 | 377.994 | 6.18179 | 0.209722 | 0.0425971 | 6.1991 | 0.209722 | 0.0960492 |
| 0.97 | COMPLETE_CANDIDATE_PENDING_CONVERGENCE_AND_INDEPENDENT_WHOLE_HISTORY_AUDIT | 550.57 | 502.466 | 139.37 | 19.1904 | 378.031 | 10.0252 | 0.369301 | 0.0798516 | 10.039 | 0.369301 | 0.153972 |

physically_qualifying: false. Read-only scoring of completed, audited cases.
